import numpy as np, itertools, os
from scipy import ndimage

DTYPES = {
    'int8': 0,
    'int16': 1,
    'uint8': 2,
    'uint16': 3,
    'float16': 4}

# ======================================================================
# LOAD FUNCTIONS |
# ======================================================================

def load(filename, infos=None, init_infos_only=False, ranges_only=False, mmap_only=False, clip=False):
    """
    Method to load *.mvk file

    """
    if infos is None:
        infos = {}

    # --- Load header and kernel
    header, kernel, offset = load_header_kernel(filename, infos)

    # --- Validate
    infos = init_infos(infos, header)
    infos = validate_infos(infos)

    # --- Determine scale of reconstruction (range along FIRST axis of stacked) 
    kernel_sub, kernel_sub_indices = create_reconstruction_kernel(header, infos, kernel)

    # --- Determine affine indices and reconstruction shape 
    affine_indices, ranges = determine_affine_indices(header, infos, kernel_sub, ranges_only, clip)

    # --- Determine bounds for reconstruction (range along REMAINING axes of stacked)
    bounds, paddings = create_reconstruction_bounds(header, infos, kernel_sub)

    # --- Exit early if purpose is simply to initialize the infos dictionary
    if init_infos_only:
        return header, affine_indices, ranges

    # --- Load mmap
    mmap = infos.pop('mmap') if 'mmap' in infos else \
        np.memmap(filename, mode='r', dtype=header['dtype'], offset=offset, shape=tuple(header['shape_vol']))

    # --- Finalize volume
    trim = None
    if infos['full_res']:
        if 'trim' in infos:
            trim = infos.pop('trim')
        else:
            e = np.prod(header['shape_vol']) * np.array([0], dtype=header['dtype']).itemsize
            trim = np.memmap(filename, mode='r', dtype=header['dtype'], offset=offset + int(e))

    # --- Exit early if purpose is simply to load mmap into memory
    if mmap_only:
        return mmap[:kernel_sub_indices.size], trim

    # --- Reconstruct image based on kernel_sub, bounds and paddings 
    vol = reconstruct_image(mmap, header, kernel_sub_indices, bounds, paddings)
    vol = overflow_add(vol, trim, header)

    # --- Apply affine indices 
    if affine_indices.size > 0:
        m = np.min(vol)

        if not clip:
            vol = ndimage.map_coordinates(vol, affine_indices, order=1, mode='constant', cval=m)

        else:
            vol[:, :, :1] = m
            vol[:, :, -1:] = m
            vol[:, :, :, :1] = m
            vol[:, :, :, -1:] = m
            vol = vol[affine_indices[0], affine_indices[1], affine_indices[2], affine_indices[3]]

    return np.moveaxis(vol, 0, -1), header

def sampling_indices(infos):
    """
    Method to determine underlying sampling indices

    """
    # --- Early exit if header and mvk_source do not exist
    if infos['mvk_source'] is None:
        return None, None, np.array([], dtype='uint8')
    
    # --- Call load() to initialize header
    header, affine_indices, ranges = load(
        filename=infos['mvk_source'], infos=infos, init_infos_only=True, ranges_only=not infos['affine'], clip=True)

    # ==========================================================================================
    # OVERFLOW SAMPLING 
    # ==========================================================================================
    # 
    # If full resolution is NOT requested, then the sampling indices do NOT include the overflow
    # portion of the image (e.g. the extra portions of the image that are removed to make the
    # underlying reconstruction kernel evenly divisible). For example:
    # 
    #  original image = 102 slices (at 1 mm thickness)
    #  requested tile = 4 mm spacing
    #  reconstruction = 25 slices interleaved x 4 with 2 slices overflow
    #  
    # In scenario, the 2 extra slices are removed (e.g. considered overflow) somewhere in the
    # MIDDLE of the volume, thus to determine the original sampling indices, one must first
    # determine the indices of the core 100 slice (or 25-/50- slice) reconstruction. This is 
    # calculated by determining the set difference between all indices and the 'indices_trim'
    # 
    # ==========================================================================================

    indices_overflow = []
    for orig, recon in zip(header['shape_original'], header['shape_vol'][1:]):

        trim = orig % recon

        # --- No overflow present along this dimension
        if trim == 0:
            indices_overflow.append(np.arange(orig))

        # --- Overflow present ==> remove indices_trim to determine indices of core recon 
        else:
            indices_trim = np.linspace(0, orig, trim, endpoint=False).astype('int')
            indices_keep = np.setdiff1d(np.arange(orig), indices_trim, assume_unique=True)
            indices_overflow.append(indices_keep)

        # --- Pad
        # indices_overflow[-1] = np.pad(indices_overflow[-1], pads, 
        #     mode='linear_ramp', end_values=(-pads[0], indices_overflow[-1][-1] + pads[1]))

    # ==========================================================================================
    # INTERLEAVE 
    # ==========================================================================================
    # 
    # The final reconstructed image is created by interleaving N number of base subimages. Each
    # subimage is painted over the final larger image at equal spacing equal to sqrt(N). For example,
    # a total of sixeteen (16) 1 x 25 x 25 subimages can be interleaved together to form one larger 
    # 1 x 100 x 100 image, each added with a stride of 4 in each direction. 
    # 
    # The final true indices of the reconstructed construction however must take into account:
    # 
    #   (1) The offsets generated by overflow removal above
    #   (2) Ranges for affine indices (if present)
    # 
    # Thus the algorithm is as follows:
    # 
    #   (1) Determine indices based on pure interleave pattern [0, 1, 2, 3... 98, 99] per above
    #   (2) Map interleave indices to overflow indices [0, 1, 2, ... 50, 52, ... 100, 101] per aboe
    #   (3) Map overflow indices to ranges for affine indices [0, 2, 4, ..., 96, 98, 100]
    # 
    # Note that affine indices can be parameterized in two ways. If the affine indices are evenly
    # spaced, a series of ranges (derived from mvk.load()) can be provided and used to perform
    # indexing directly during the mzl.decompress() call. However, if skewing, rotation, etc is 
    # defined (e.g. if affine indices are explicitly created) then this function will simply return
    # the indices after interleave (step 2) but skip step 3 so that the affine indices can be 
    # applied to the loaded mzl volume.
    # 
    # ==========================================================================================
    
    indices = []
    padding = []

    for ax, shape, step, bounds, vp, overflow, rng in zip(np.arange(header['kernel_sub'].ndim), header['kernel_sub'].shape, 
        header['kernel'].shape, header['bounds_original'], infos['valid_padding'], indices_overflow, ranges):

        # --- (1a) Determine interleave indices 
        axis_slices = [0] * header['kernel_sub'].ndim
        axis_slices[ax] = slice(0, shape)
        pattern = header['kernel_sub'][tuple(axis_slices)].ravel()
        b_stop, b_start = bounds.stop, bounds.start
        if infos['valid']: 
            b_stop -= vp
            b_start += vp
        index = np.zeros(shape * (b_stop - b_start), dtype='int')
        for p in pattern:
            index[p-1::shape] = np.arange(b_start, b_stop) * step + p - 1

        # --- (1b) Pad < 0 with -1
        if index[0] < 0:
            pv = abs(index[0]) 
            overflow = np.pad(overflow, (pv, 0), mode='constant', constant_values=-1)

        # --- (1c) Pad > overflow with -2
            index += pv 
        if index[-1] >= len(overflow):
            pv = index[-1] - len(overflow) + 1
            overflow = np.pad(overflow, (0, pv), mode='constant', constant_values=-2)

        # --- (2) Map interleaved indices to overflow indices
        index = overflow[index]

        # --- (3a) Map overflow indices to ranges
        if len(rng) > 0 and not infos['affine']:
            index = index[rng]

        # --- (4) Remove padded entries (-1 or -2)
        vp_ = vp if infos['valid'] else 0
        padding.append((np.count_nonzero(index == -1) + vp_, np.count_nonzero(index == -2) + vp_))
        index = index[index >= 0]

        indices.append(index)

    return indices[1:] + [indices[0]], padding[1:] + [padding[0]], affine_indices

def apply(vol, infos):
    """
    Method to apply subsampling to volume

    To apply subsampling parameters, infos['mvk_source'] must contain either:

      (1) path to source *.mvk file 
      (2) header dict from previous load

    """
    # --- Early exit if mvk_source does not exist or full res
    if infos['mvk_source'] is None or infos['full_res']:
        return np.moveaxis(vol, 0, -1) 
    
    # --- Call load() to initialize header into infos
    header, affine_indices, ranges = load(filename=infos['mvk_source'], infos=infos, init_infos_only=True)
    vol, infos = validate(vol, infos)

    # --- Apply subsampling kernel to create reconstruction
    recon = apply_kernel_sub(vol, infos, header)

    # --- Apply fancying indexing (affines, etc)
    if affine_indices.size > 0:
        recon = recon[
            affine_indices[0], affine_indices[1],
            affine_indices[2], affine_indices[3]]

    return np.moveaxis(recon, 0, -1) 
    
def apply_kernel_sub(vol, infos, header):
    """
    Method to apply subsampling kernel to image

    """
    if infos['full_res']:
        return vol

    # --- Remove overflow from vol
    vol, _, _, _ = overflow_remove(vol, header['shape_vol'][1:])

    # --- Initialize recon if interleaving is required 
    if header['kernel_sub'].size > 1:
        slice_length = lambda s : s.stop - s.start
        recon_shape = [slice_length(s) * k for s, k in zip(header['bounds'], header['kernel_sub'].shape)]
        recon = np.zeros(recon_shape, dtype=vol.dtype)

    for i in np.sort(header['kernel_sub_indices'].ravel()):

        # --- Determine slices in volume for source 
        coords = np.nonzero(header['kernel_sub_mask'] == i)
        coords = [c[0] for c in coords]
        slices_vol = []
        paddings = []
        for offset, bound, shape, step in zip(coords, header['bounds_original'], vol.shape, 
            header['kernel'].shape): 

            # --- Determine start and stop
            lo = offset + bound.start * step 
            hi = offset + bound.stop * step

            # --- Determine if range is beyond image and if so, pad
            indices = np.arange(lo, hi, step)
            l_pad = np.count_nonzero(indices < 0)
            h_pad = np.count_nonzero(indices >= shape)

            if l_pad > 0:
                indices = indices[l_pad:]
            if h_pad > 0:
                indices = indices[:-h_pad]

            slices_vol.append(slice(indices[0], indices[-1] + 1, step))
            paddings.append((l_pad, h_pad))

        # --- Reconstruct
        if header['kernel_sub'].size > 1:
            # --- Determine slices in recon for destination
            coords = np.nonzero(header['kernel_sub_indices'] == i)
            coords = [c[0] for c in coords]
            slices_recon = []
            for c, s, step in zip(coords, recon.shape, header['kernel_sub_indices'].shape):
                slices_recon.append(slice(c, s, step))
            recon[slices_recon] = vol[slices_vol]
        else:
            recon = vol[slices_vol]

    # --- Pad if needed
    if np.sum(paddings) > 0:
        recon = np.pad(recon, paddings, mode='constant', constant_values=np.min(recon))

    return recon

def load_header(filename=None, infos=None):
    """
    Method to return header only

    """
    header, kernel, offset = load_header_kernel(filename, infos) 
    return header

def load_header_kernel(filename, infos=None):
    """
    Method to load 104-byte header and interleave kernel

    """
    if infos is None:
        infos = {}

    if 'mvk_source' in infos:
        if type(infos['mvk_source']) is dict:
            if 'header' in infos['mvk_source']:
                header = infos['mvk_source']['header']
                kernel = infos['mvk_source']['kernel']
                offset = infos['mvk_source']['offset']

                return header, kernel, offset

    header = np.memmap(filename, mode='r', dtype='uint32', shape=(26,))
    header = parse_header(header=header.tobytes())

    kernel = np.memmap(filename, mode='r', dtype=header['dtype'], offset=104, shape=tuple(header['shape_kernel']))
    kernel = np.array(kernel, dtype='int32')
    kernel.ravel()[0] = 1

    itemsize = np.array([0], dtype=header['dtype']).dtype.itemsize
    offset = 104 + int(np.prod(header['shape_kernel']) * itemsize)

    infos['mvk_source'] = {
        'header': header,
        'kernel': kernel,
        'offset': offset}

    return header, kernel, offset

def create_reconstruction_kernel(header, infos, kernel):
    """
    Method to create reconstruction kernel_sub and kernel_sub_indices

    Variables in this method:

      (list) scales : [n0, n1, n2, ..., ni] where ni is an integer representing multiple
      of base resolution needed to achieve target resolution. For example, given a base
      resolution of [1, 32, 64, 64] and target resolution of [1, 64, 128, 128], scales would
      be set to [1, 2, 2, 2].

    :return

      (np.array) kernel_sub: see subsample_kernel()
      (np.array) kernel_sub_indices : see subsample_kernel()

    """
    if infos['full_res']:
        kernel_sub = kernel
        scales = kernel_sub.shape
        infos['voxel_size_recon'] = infos['voxel_size'].copy()

    else:
        # --- Determine scale needed for reconstruction along each dimension
        resolutions = find_available_resolutions(header, kernel, include_full_res=False)
        res_list = [resolutions[:, i] for i in range(resolutions.shape[1])]
        voxel_size = [v * k for v, k in zip(header['voxel_size'], kernel.shape)]
        scales = []
        infos['voxel_size_recon'] = []

        for s, t, z, r, v in zip(infos['shape'], infos['tiles'], infos['rsize'], res_list, voxel_size):
            # --- For non-tiling axis, scale is determined by overall number of elements needed
            if t == 0:
                length = z if z > 0 else s
                assert length > 0, 'Error shape must be set for a non-tiling axis'
                scale = np.nonzero(r >= length)[0]
                scale = scale[0] + 1 if len(scale) > 0 else len(r)
                scales.append(scale)
                infos['voxel_size_recon'].append(float(v))
            # --- For tiling axis, scale is determined by tile size
            elif s >= 0 and t > 0:
                scale = max(int(round(v / t)), 1)
                scales.append(scale)
                infos['voxel_size_recon'].append(float(v / scale))

    if infos['tiles_flexible']:
        infos['tiles'] = [v if t > 0 else 0 for v, t in zip(infos['voxel_size_recon'], infos['tiles'])]

    # --- Generate kernel_sub from requested scales
    kernel_sub, kernel_sub_indices, kernel_sub_mask = subsample_kernel(kernel=kernel, scales=scales)
    
    header['kernel'] = kernel
    header['kernel_sub'] = kernel_sub
    header['kernel_sub_indices'] = kernel_sub_indices
    header['kernel_sub_mask'] = kernel_sub_mask

    return kernel_sub, kernel_sub_indices

def find_available_resolutions(header, kernel, include_full_res=True, verbose=False):
    """
    Method to list all resolutions possible at each scale

    :return

      (np.array) resolutions : [[c0, z0, i0, j0],
                                [c1, z1, i1, j1],
                                [c2, z2, i2, j2],
                                ...]

    """
    resolutions = []
    if verbose: 
        print('Avaiable resolutions:')
        fmt = 'Scale %0i: (%i' + ', %i' * (len(header['shape_vol']) - 2) + ')'
    for i in range(1, np.max(kernel) + 1):
        kernel_sub, _, _ = subsample_kernel(kernel, scales=[i] * len(kernel.shape))
        resolutions.append([s * k for s, k in zip(header['shape_vol'][1:], kernel_sub.shape)])
        if verbose: print(fmt % tuple([i] + resolutions[-1]))
    
    # --- Add full resolution
    if include_full_res:
        res_full = [r - pad + trim for r, pad, trim in zip(resolutions[-1], header['shape_pad'], header['shape_trim'])]
        resolutions.append(res_full)
        if verbose: print(fmt.replace('Scale %0i', 'Fullres') % tuple(resolutions[-1]))

    return np.array(resolutions)

def subsample_kernel(kernel, scales):
    """
    Method to subsample kernel based on specified scale along each axis 

    :params

      (np.array) kernel : original C x Z x I x J interleave kernel
      (list) scales : see create_reconstruction_kernel()

    :return

      (np.array) kernel_sub : c x z x i x j interleave kernel containing only elements 
      needed for reconstruction. Note that c <= C, z <= Z, i <= I, j <= J.

      (np.array) kernel_sub_indices : c x z x i x j matrix with indices representing
      filling order of interleaved data.

      (np.array) kernel_sub_mask : C x Z x I x J matrix containing original 
      interleave kernel, with unused elements set to -1.

    """
    assert len(scales) == len(kernel.shape)
    kernel.ravel()[0] = 1
    inds = determine_kernel_filling_order(kernel)

    # --- Create mesh grid containing indices of kernel to keep
    indices = []
    for ax, scale in enumerate(scales):
        ax_slice = [0] * len(scales)
        ax_slice[ax] = slice(0, kernel.shape[ax], 1)
        axis = list(kernel[tuple(ax_slice)])
        index = []
        for s in range(1, scale + 1):
            if s in axis:
                index.append(axis.index(s))
        indices.append(sorted(index))

    mg = np.meshgrid(*indices, indexing='ij')
    kernel_sub = kernel[tuple(mg)]
    kernel_sub_indices = inds[tuple(mg)]
    kernel_sub_mask = np.zeros(kernel.shape, dtype=kernel.dtype) - 1
    kernel_sub_mask[tuple(mg)] = inds[tuple(mg)] 

    return kernel_sub, kernel_sub_indices, kernel_sub_mask

def determine_kernel_filling_order(kernel):
    """
    Method to create a matrix equal in size to kernel with indices representing filling order

    """
    index = 0
    kernel_indices = np.zeros(kernel.shape, dtype=kernel.dtype)
    for i in range(1, int(max(kernel.ravel())) + 1):
        n = np.count_nonzero(kernel == i) 
        kernel_indices[kernel == i] = np.arange(index, index + n) 
        index += n

    return kernel_indices

def determine_affine_indices(header, infos, kernel_sub, ranges_only, clip=False):
    """
    Method to:
    
      (1) Determine indices corresponding to affine transformation. Note that these indices
          also take into account reconstruction shapes that are not an even multiple of the 
          base resolution. For example if base resolution is [1, 32, 64, 64] and requested
          infos['shape'] = [1, 48, 96, 96], then a full [1, 64, 128, 128] reconstruction shape
          will be provided and affine_indices will be created such that the final image will
          match the requested shape.

      (2) Determine necessary reconstruction shape, accounting for affine transforms that extend
          beyond the original FOV. For example given a base resolution of [1, 32, 64, 64] and 
          a requested infos['shape'] = [1, 32, 64, 64] with oblique affine transformation, an
          extend FOV of [1, 64, 128, 128] will be requested since the affine_indices will extend
          beyond the original FOV.

    :return

      (np.array) affine_indices : either an 4 x C x Z x I x J set of coordinates or a matrix
      of size = 0 if no special transformation is necessary

      (list) infos['shape_recon'] :  reconstruction shape used to determine bounds

    """
    affine_indices = np.array([])
    ranges = [np.array([])] * 4

    # --- DETERMINE:  infos['shape'] 
    # 
    # NOTE: This shape represents the final target shape after affine_indices reconstruction (if necessary) 
    # is completed (and returned to the user). For infos['valid'] == False the specified infos['shape']
    # is used, however if infos['valid'] == True then all tiling axes are expanded to full resolution.
    # This resolution is determined by the fully-expanded kernel, for example along a certain axis:
    # 
    #   (shape_vol of 128) * (kernel_sub.shape of 2) = (infos['shape'] of 256)
    # 
    # ... unless a rsize is specified, in which case the reconstruction size is used.
    full_kernel_shape = [s * k for s, k in zip(header['shape_vol'][1:], kernel_sub.shape)]
    if infos['valid'] and infos['valid_expansion']:
        shape = []
        for s, t, z, v, f in zip(infos['shape'], infos['tiles'], infos['rsize'], infos['voxel_size_recon'], full_kernel_shape):
            if t > 0:
                # If tiling, use f unless infos['rsize'] is specified
                d = round(f * v / t) if z == 0 else z  
            else:
                # If non-tiling, use infos['shape']
                d = s 
            shape.append(int(d))
        infos['shape'] = shape

    # --- DETERMINE: shape_recon
    # 
    # NOTE: This shape is the intermediate reconstructed shape before application of affine_indices. By
    # definition, this shape either represents:
    # 
    #  (1) The fully-expanded kernel (for all non-tiling axes)
    #  (2) The infos['shape'] rounded to the nearest reconstruction resolution MODIFIED by a factor that
    #      accounts for any discrepencies between the fully-expanded kernel shape and specified rsize. For
    #      example, if the fully-expanded kernel shape is 128 and the rsize is 256, then the reconstruction 
    #      shape will be divided by 2 so that the FOV would approximate that of a full 256 matrix. The 
    #      discrepency in final shape will then be bridged by the affine_indices reconstruction.
    if infos['full_res']:
        shape_recon = header['shape_original']
    else:
        shape_recon = []
        for s, t, z, v, k, f in zip(infos['shape'], infos['tiles'], infos['rsize'], infos['voxel_size_recon'],
                kernel_sub.shape, full_kernel_shape):

            # By default (non-tiling, non-rsize) use full kernel shape
            if (t == 0 and z == 0):
                span = f
            else:
                # Determine baseline span
                span = round(np.ceil(s / k)) * k                  

                # If tiles is specified, modify the span
                if t > 0 and v != t:
                    span = round(span * t / v)

                # If rsize is specified, modify the span
                elif z > 0:
                    span = round(span * (f / z))

                # Span cannot be larger than full kernel shape
                span = min(span, f)

            shape_recon.append(span)

    steps = [r / i if i > 0 else 1 for r, i in zip(shape_recon, infos['shape'])]

    # --- Early exit
    if (np.array(steps) == 1).all() and not infos['affine']:
        infos['shape_recon'] = [int(s) for s in shape_recon] 
        return affine_indices, ranges 

    # --- Determine ranges using image resolution
    offsets = [shape / 2 for shape in shape_recon]
    ranges = [np.linspace(0, shape_r, num=shape_i, endpoint=False) - offset for 
        shape_r, shape_i, offset in zip(shape_recon, infos['shape'], offsets)]

    # --- If meshgrid affine_indices is requested 
    if not ranges_only:

        # --- Create meshgrid from ranges as needed
        mg = np.meshgrid(*ranges, indexing='ij') 

        # --- Update indices accounting for affine transform
        if infos['affine']:

            # --- Apply affine
            affine_indices = np.array([i.flatten() for i in mg[1:]] + [np.ones(mg[0].size)]) 
            affine_indices = np.dot(infos['tform'], affine_indices)
            affine_indices = np.concatenate((mg[0].reshape(1, -1), affine_indices[:-1]))
            affine_indices += np.array(offsets).reshape(4, 1) 

            if clip:
                np.floor(affine_indices, out=affine_indices)
                affine_indices = affine_indices.astype('int32')

            for n, t, z in zip(np.arange(len(infos['tiles'])), infos['tiles'], infos['rsize']):
                if t > 0 or z > 0:
                    # --- For tiling axes, increase FOV as needed
                    m = np.min(affine_indices[n])
                    shape_recon[n] = np.max(affine_indices[n]) - m + 1
                    affine_indices[n] = affine_indices[n] - m 
                else:
                    # --- For non-tiling axes, clip indices to FOV
                    if clip:
                        np.clip(affine_indices[n], 
                            a_min=0,
                            a_max=shape_recon[n] - 1, 
                            out=affine_indices[n])

            affine_indices = affine_indices.reshape(4, infos['shape'][0], infos['shape'][1], infos['shape'][2], infos['shape'][3])

        else: 
            affine_indices = np.stack(mg).reshape(4, -1)
            affine_indices += np.array(offsets).reshape(4, 1)
            
            if clip:
                np.floor(affine_indices, out=affine_indices)
                affine_indices = affine_indices.astype('int32')

            affine_indices = affine_indices.reshape(4, infos['shape'][0], infos['shape'][1], infos['shape'][2], infos['shape'][3])

    # --- Finalize ranges
    ranges = [np.floor(r + o).astype('int') for r, o in zip(ranges, offsets)]

    # --- Save and return
    infos['shape_recon'] = [int(s) for s in shape_recon] 

    return affine_indices, ranges

def create_reconstruction_bounds(header, infos, kernel_sub):
    """
    Method to create bounds and padding along each axis for which to load image

    """
    bounds = []
    paddings = []

    # --- Full resolution reconstruction
    if infos['full_res']:
        bounds = [slice(0, v, 1) for v in header['shape_vol'][1:]]
        paddings = [(0, 0)] * len(header['shape_vol'][1:])

    # --- Subsampled reconstruction
    else: 
        for s, t, z, v, k, p, vp in zip(infos['shape_recon'], infos['tiles'], infos['rsize'],
            header['shape_vol'][1:], kernel_sub.shape, infos['point'], infos['valid_padding']):

            # --- For non-tiling axis, bounds is 0 to end
            valid = infos['valid'] and infos['valid_expansion']
            if (s > 0 and t == 0 and z == 0) or valid:
                bounds.append(slice(0, v, 1))
                pd = 0
                if valid: 
                    pd = vp
                elif s > v * k: 
                    pd = int(np.ceil((s - (v * k)) / 2))
                paddings.append((pd, pd))

            # --- For tiling axis, bounds is determined by shape and point 
            elif s > 0 and (t > 0 or z > 0):

                # --- Determine midpoint and range (lo, hi)
                center = int(v * p) # equivalent to floor round
                span = int(np.ceil(s / k))
                if span % 2 == 0:
                    lo = center - int(span / 2) + 1
                    hi = center + int(span / 2) + 1
                if span % 2 == 1:
                    lo = center - int((span - 1) / 2)
                    hi = center + int((span - 1) / 2) + 1

                # --- Determine padding (if necessary)
                padding = [0, 0]
                if lo < 0:
                    padding[0] = abs(lo) * k
                    lo = 0
                if hi > v:
                    padding[1] = (hi - v) * k
                    hi = v

                # --- Save values
                bounds.append(slice(lo, hi, 1))
                paddings.append(tuple(padding))

    header['bounds_original'] = [slice(s.start - p[0], s.stop + p[1], 1) for s, p in zip(bounds, paddings)] 
    header['bounds'] = bounds
    header['paddings'] = paddings
                
    return bounds, paddings

def reconstruct_image(mmap, header, kernel_sub_indices, bounds, paddings):

    # --- If interleaving needed
    if kernel_sub_indices.size == 1:
        recon = mmap[tuple([0] + bounds)]
        if not recon.flags['WRITEABLE']:
            recon = np.array(recon)

    else:

        # --- Create recon 
        slice_length = lambda s : s.stop - s.start
        recon_shape = [slice_length(s) * k for s, k in zip(bounds, kernel_sub_indices.shape)]
        recon = np.zeros(recon_shape, dtype=mmap.dtype)

        for ch in np.sort(kernel_sub_indices.ravel()):
            coord = np.nonzero(kernel_sub_indices == ch)
            slices = []
            for c, stop, k in zip(coord, recon_shape, kernel_sub_indices.shape):
                slices.append(slice(int(c), stop, k))
            recon[tuple(slices)] = mmap[tuple([ch] + bounds)]

    # --- Apply padding
    if np.sum(paddings) > 0:
        recon = np.pad(recon, paddings, mode='constant', constant_values=np.min(recon))

    return recon

# ======================================================================
# HEADER FUNCTIONS |
# ======================================================================

def save_header(vol, kernel, shape_pad, shape_trim, infos):
    """
    Method to create *.mvk header

    """
    # Create uint32 entries (shapes)
    i = np.zeros(22, dtype='uint32')
    i[0:1] = DTYPES[str(vol.dtype)]
    i[1:6] = vol.shape
    i[6:10] = kernel.shape
    i[10:14] = infos['shape_chunk'] 
    i[14:18] = shape_pad
    i[18:22] = shape_trim

    # Create float32 entries (voxel_size)
    f = np.zeros(4, dtype='float32')
    f[0:4] = infos['voxel_size']

    buf = i.tobytes() + f.tobytes()

    return np.frombuffer(buf, dtype=vol.dtype)

def parse_header(filename=None, header=None):

    if filename is not None and header is None:
        header = np.memmap(filename, mode='r', dtype='uint32', shape=(26,))
        header = header.tobytes()

    headers_int = {
        'dtype': [0, 1],
        'shape_vol': [1, 6],
        'shape_kernel': [6, 10],
        'shape_chunk': [10, 14],
        'shape_pad': [14, 18],
        'shape_trim': [18, 22]}

    headers_float = {
        'voxel_size': [22, 26]}

    h = {}

    hdr = np.frombuffer(header, dtype='uint32')
    for key, rng in headers_int.items():
        h[key] = hdr[rng[0]:rng[1]] 

    hdr = np.frombuffer(header, dtype='float32')
    for key, rng in headers_float.items():
        h[key] = hdr[rng[0]:rng[1]]

    dtype_key = dict([(value, key) for key, value in DTYPES.items()])
    h['dtype'] = dtype_key[int(h['dtype'])]

    # --- Determine shape_original
    h['shape_original'] = [v * k - p + t for v, k, p, t in zip(
        h['shape_vol'][1:],
        h['shape_kernel'],
        h['shape_pad'],
        h['shape_trim'])]

    return h

# ======================================================================
# SAVE FUNCTIONS |
# ======================================================================

def save(vol, filename, infos, verbose=False):
    """
    Method to save an input volume in *.mvk format

    :params

      (dict) infos = {
        'shape': [1, z, x, y],  # use shape to determine subsampled vol
        'tiles': [1, z, x, y],  # use tiles to determine subsampled vol
        'voxel_size': ...
      }

    Header 

      BYTES   : NAME
      ------------------------
      000-008 : dtype
      008-024 : shape_vol
      024-040 : shape_kernel
      040-056 : shape_chunk
      056-072 : shape_pad
      072-088 : shape_trim
      088-104 : voxel_size (original)

    Data

      BYTES
      -----------------------
      104-xxx : kernel
      xxx-xxx : data
      xxx-xxx : trim

    """
    infos = init_infos(infos)
    vol, infos = validate(vol, infos.copy(), verbose=verbose)
    resolution, infos = determine_resolution_save(vol, infos)
    vol, shape_pad, shape_trim, trim = overflow_remove(vol, resolution)
    vol, kernel = interleave(vol, resolution)
    vol, infos = chunk(vol, infos)
    header = save_header(vol, kernel, shape_pad, shape_trim, infos)

    # --- Save file
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    buf = np.concatenate((header, kernel.ravel(), vol.ravel(), trim.ravel()), axis=0)
    mmap = np.memmap(filename, mode='w+', dtype=buf.dtype, shape=buf.shape)
    mmap[:] = buf[:]
    del mmap

def init_infos(infos, header=None):
    """
    Method to initialize infos

    """
    # --- Init shape: default value for full_res
    if infos['full_res'] and 'shape' not in infos:
        infos['shape'] = header['shape_original'][-4:]
        infos['shape'] = [int(i) for i in infos['shape']]

    # --- Init keys: shape, tiles, rsize
    length = [len(infos[key]) for key in ['shape', 'tiles', 'rsize'] if key in infos]
    length = list(set(length))
    assert len(length) == 1, 'Error lengths must match (shape == tiles == rsize) and at least one must be defined'
    for key in ['shape', 'tiles', 'rsize']:
        if key not in infos:
            infos[key] = [0] * length[0]

    # --- Init keys: point
    if 'point' not in infos: infos['point'] = [0.5] * len(infos['tiles'])
    assert len(infos['point']) == len(infos['tiles'])

    # --- Init keys: voxel_size
    if 'voxel_size' not in infos:
        infos['voxel_size'] = [1] * len(infos['tiles'])
    assert len(infos['voxel_size']) == len(infos['tiles'])

    # --- Init keys: valid_padding 
    if 'valid_padding' not in infos:
        infos['valid_padding'] = [0] * len(infos['tiles'])
    assert len(infos['valid_padding']) == len(infos['tiles'])

    # --- Init affine, valid, tiles_flexible
    for key in ['affine', 'valid', 'tiles_flexible']:
        if key not in infos:
            infos[key] = False

    # --- Ensure that all iterables are lists
    for key in ['shape', 'tiles', 'rsize', 'voxel_size', 'valid_padding']:
        assert type(infos[key]) is list

    return infos

def validate(vol, infos, verbose=False):
    """
    Method to validate volume
    
      (1) Ensure that volume is either 1- or 2-bytes in size

          Note that 4- or 8-byte precision data (int32/64 or float32/64) 
          are never obtained for medical images

      (2) Ensure that volume is 4 dimensions (and that channel is stacked first)

    """
    if vol.dtype.itemsize > 2:
        dtype = str(vol.dtype)[:-2] + '16'
        if verbose: print('Converting volume to %s' % dtype)
        vol = vol.astype(dtype)

    assert str(vol.dtype) in DTYPES

    # --- 4D volume
    if vol.ndim == 4 and len(infos['shape']) == 3 and vol.shape[-1] > 1: 
        vol = np.moveaxis(vol, -1, 0)
        infos = expand_infos(infos)
        infos['shape'][0] = vol.shape[0]

        return vol, infos

    # --- 3D volume
    if vol.ndim == 4 and len(infos['shape']) == 3 and vol.shape[-1] == 1: 
        vol = np.squeeze(vol, axis=3)

    for shape in [2, 3]:
        if len(vol.shape) == shape:
            vol = np.expand_dims(vol, axis=0)
            infos = expand_infos(infos)

    origs = infos['mvk_source']['header']['shape_original'] if infos['mvk_source'] is not None else [1] * len(infos['shape'])
    infos['shape'] = [i if i is not None else s for i, s in zip(infos['shape'], origs)]

    assert len(vol.shape) == 4, 'Error incompatible volume shape'

    return vol, infos

def validate_infos(infos):
    """
    Method to validate infos only (otherwise identical to validate())

    """
    for shape in [2, 3]:
        if len(infos['shape']) == shape:
            infos = expand_infos(infos)

    origs = infos['mvk_source']['header']['shape_original'] if infos['mvk_source'] is not None else [1] * len(infos['shape'])
    infos['shape'] = [i if i is not None else s for i, s in zip(infos['shape'], origs)]

    return infos

def expand_infos(infos):
    """
    Method to expand infos with default values

    """
    if 'shape' in infos: infos['shape'] = [None] + infos['shape']
    if 'tiles' in infos: infos['tiles'] = [0] + infos['tiles']
    if 'rsize' in infos: infos['rsize'] = [0] + infos['rsize']
    if 'scale' in infos: infos['scale'] = [0] + infos['scale']
    if 'point' in infos: infos['point'] = [None] + infos['point']
    if 'valid_padding' in infos: infos['valid_padding'] = [0] + infos['valid_padding']
    if 'voxel_size' in infos: infos['voxel_size'] = [1] + infos['voxel_size']

    return infos

def determine_resolution_save(vol, infos):
    """
    Method to determine subsampling resolution based on shape, tiles and/or scale 

    """
    # --- Fill in resolution based on missing shape data (e.g == 0) 
    resolution = []
    for s, t, v, w in zip(infos['shape'], infos['tiles'], infos['voxel_size'], vol.shape):
        # --- For non-tiling axis, resolution is simply the provided shape
        if s > 0:
            resolution.append(min(s, w))
        elif t > 0:
        # --- For tiling axis, resolution is determined by tile size
            step = max(int(round(t / v)), 1)
            shape = max(int(w / step), 1)
            resolution.append(shape)

    return resolution, infos

def overflow_remove(vol, resolution):
    """
    Overflow is defined as shape % res where shape is the original volume size and 
    resolution is the target save resolution. This method removes the "overflow" along
    each axis of volume such that volume.shape is evenly divisible by resolution.

    :return

      (np.array) vol : subsampled volume
      (list) shape_pad : [] (deprecated)
      (list) shape_trim : length of overflow along each dimension
      (np.array) trim : buffer of overflow values

    NOTE: alterations to overflow management method require corresponding alterations
    in sampling_indices()

    """
    shape_pad = [0, 0, 0, 0]
    shape_trim = [shape % res for shape, res in zip(vol.shape, resolution)]
    
    if np.array(shape_trim).any():

        trims = []
        s = [slice(0, i, 1) for i in vol.shape]
        t = s.copy()

        for ax, shape in enumerate(shape_trim):
            if shape > 0:

                indices_trim = np.linspace(0, vol.shape[ax], shape, endpoint=False).astype('int')
                if indices_trim[-1] == vol.shape[ax]: indices_trim[-1] -= 1
                indices_keep = np.setdiff1d(np.arange(vol.shape[ax]), indices_trim, assume_unique=True)

                s[ax] = indices_trim 
                trims.append(vol[s].ravel())

                s[ax] = indices_keep
                t[ax] = slice(0, indices_keep.size)
                vol[t] = vol[s]
                s = t.copy()

        vol = vol[[slice(0, s - t, 1) for s, t in zip(vol.shape, shape_trim)]]
        trim = np.concatenate(trims, axis=0)

    else:
        trim = np.array([], dtype=vol.dtype)

    return vol, shape_pad, shape_trim, trim

def overflow_add(vol, trim, header):
    """
    Overflow is defined as shape % res where shape is the original volume size and 
    resolution is the target save resolution. This method adds the "overflow" along
    each axis of volume such that the original volume size is recreated. 
    
    """
    if trim is None:
        return vol

    if trim.size == 0:
        return vol

    s = [slice(0, i, 1) for i in vol.shape]
    t = s.copy()
    pad_array = [(0, s) for s in header['shape_trim']]
    vol = np.pad(vol, pad_array, mode='constant')
    offset = trim.size 

    for ax, shape in enumerate(header['shape_trim'][::-1]):
        if shape > 0:
            indices_trim = np.linspace(0, vol.shape[3-ax], shape, endpoint=False).astype('int')
            if indices_trim[-1] == vol.shape[3-ax]: indices_trim[-1] -= 1
            indices_keep = np.setdiff1d(np.arange(vol.shape[3-ax]), indices_trim, assume_unique=True)
            
            t[3-ax] = indices_keep
            vol[t] = vol[s].copy()
            # vol[t] = vol[s].ravel().reshape(vol[t].shape)

            t[3-ax] = indices_trim
            length = vol[t].size
            vol[t] = trim[offset - length:offset].reshape(vol[t].shape)
            offset -= length

            s[3-ax] = slice(0, vol.shape[3-ax])
            t = s.copy()

    return vol

def interleave(vol, resolution):
    """
    Method to interleave volume based on resolution 

    Note, prior to calling this function ensure that the volume is properly padded
    with Nan so that it is evenly divisible by resolution 

    """
    # --- Confirm that volume is evenly divisible by resolution 
    steps = [shape / res for shape, res in zip(vol.shape, resolution)]
    assert not np.array([s % 1 for s in steps]).any(), 'Error volume overflow not applied correctly'
    steps = [int(s) for s in steps]

    kernel = create_interleave_kernel(steps)

    resolution = [int(r) for r in resolution]
    resolution = [kernel.size] + resolution
    stacked = np.zeros(resolution, dtype=vol.dtype)

    # --- Simple copy if no interleave is required
    if max(steps) == 1:
        stacked[0] = vol

    ch = 0
    for i in range(2, max(steps) + 1):
        coords = np.nonzero(kernel == i)
        for coord in zip(*coords):
            slices = []
            for n, c in enumerate(coord):
                slices.append(slice(c, vol.shape[n], kernel.shape[n]))
            stacked[ch] = vol[slices]
            ch += 1

    return stacked, kernel.astype(vol.dtype)

def create_interleave_kernel(steps):
    """
    Method to create interleaving kernel of arbitrary dimensions (N-D) 

    The interleave kernel selects the order of offsets in which subsamples
    of the original volume are drawn from. The kernel is designed to choose
    offsets that maximize overall entropy of the subsampling pattern so that
    during progressive image reconstruction a relatively smooth image is
    created during each iterative increase in resolution.

    Note all intermediate kernels are shown with an example 2D steps = (5, 5)

    """
    # --- Determine interleave pattern for each axes
    # axes[0] = [2, 3, 5, 2, 4]
    # axes[1] = [2, 3, 5, 2, 4]

    axes = []
    for n in steps:
        p = [0] * n
        p[0] = 2
        for i in range(2, n + 1):
            c = 0 
            while True:
                c += 1
                index = int((((n - 1) / 1.618) * c) % (n - 1))
                if p[index + 1] == 0:
                    p[index + 1] = i
                    break
        axes.append(p)
    n = max(steps)

    # ===========================================
    # FILL CUBE OF INTERLEAVE PATTERN 
    # ===========================================
    kernel = np.zeros(steps)

    # --- Fill axes
    # kernel = [
    #   2-3-5-2-4
    #   3-.-.-.-.
    #   5-.-.-.-.
    #   2-.-.-.-.
    #   4-.-.-.-.
    # ]

    for i, ax in enumerate(axes):
        selection = [0] * len(axes)
        selection[i] = slice(0, len(ax), 1)
        kernel[tuple(selection)] = ax 

    # --- Fill the 2 position at each vertex
    # kernel = [
    #   2-3-5-2-4
    #   3-.-.-.-.
    #   5-.-.-.-.
    #   2-.-.-2-.
    #   4-.-.-.-.
    # ]

    twos = tuple([ax[1:].index(2) + 1 if 2 in ax[1:] else 0 for ax in axes])
    kernel[twos] = 2

    # --- Identifying vertices
    # 
    # Note, for higher order (3D or above) hypercubes, vertices are defined
    # by all coordinates containing at least 1 zero
    # 
    # 3D
    # vertices = 8 total
    #
    # 3: (i, 0, 0) x 3
    # 3: (i, j, 0) x 3
    # 1: (0, 0, 0) x 1
    # 1: (i, j, k) x 1
    # 
    # 4D
    # vertices = 16
    #
    # 4: (i, 0, 0, 0) x 4
    # 6: (i, j, 0, 0) x 6
    # 4: (i, j, k, 0) x 4
    # 1: (0, 0, 0, 0) x 1
    # 1: (i, j, k, l) x 1

    for i in range(1, len(axes) - 1):
        indices = np.zeros(len(axes))
        indices[:i] = 1
        indices = np.unique(list(itertools.permutations(indices)), axis=0)

        for inds in indices:
            two = np.array(twos) 
            two[inds.astype('bool')] = 0
            kernel[tuple(two)] = 2

    # --- Fill kernel
    for i in range(3, n + 1):
        for j in range(0, len(axes) - 1):

            # --- Add to existing planes
            # kernel = [
            #   2-3-5-2-4
            #   3-3-.-3-.
            #   5-.-.-.-.
            #   2-3-.-2-.
            #   4-4-.-4-.
            # ]
            selection = [0] * len(axes)
            plane = [0] * len(axes)
            for J in range(j + 1):
                selection[J] = slice(0, len(axes[J]))
                start = 1 if kernel.shape[J] > 1 else 0
                plane[J] = slice(start, len(axes[J]))

            if i in kernel[selection]:
                mask = kernel[selection] == i
                for k in range(1, len(axes[j + 1])):
                    selection[j + 1] = k
                    plane[j + 1] = k
                    if np.sum(kernel[plane]) > 0:
                        kernel[selection][mask] = i 

            # --- Initialize new plane
            # kernel = [
            #   2-3-5-2-4
            #   3-3-.-3-4
            #   5-.-.-.-.
            #   2-3-.-2-4
            #   4-4-.-4-4
            # ]

            if i in axes[j + 1][1:]:
                plane = [0] * len(axes)
                for J in range(0, j + 1):
                    plane[J] = slice(0, len(axes[J]))
                start = 1 if kernel.shape[J] > 1 else 0
                plane[j + 1] = slice(start, len(axes[j + 1]))
                fill = np.sum(kernel[plane], axis=j + 1)
                fill[fill > 0] = i

                ind = axes[j + 1][1:].index(i) + 1
                plane[j + 1] = ind
                kernel[plane] = fill

    return kernel

def chunk(vol, infos):
    """
    Method to chunk vol for efficient data slicing

    """
    if 'shape_chunk' not in infos:
        infos['shape_chunk'] = [1] * (len(vol.shape) - 1)

    return vol, infos

# ======================================================================
# DEPRECATED FUNCTIONS |
# ======================================================================

def manage_overflow(vol, resolution):
    """
    Method to either pad or trim volume so that it is evenly divisible based on resolution 

    :return

      (np.array) vol : padded and/or trimmed volume
      (list) shape_pad : integers representing padding applied to END of each axes
      (list) shape_trim : integers representing trim applied to END of each axes
      (np.array) trim : flattened trimmed values from original vol

    """
    shape_pad, shape_trim = [], []

    for shape, res in zip(vol.shape, resolution):
        mod = shape % res
        if mod == 0:
            shape_pad.append(0)
            shape_trim.append(0)
        # --- If overflow > half of resolution ==> pad 
        elif mod > res / 2:
            shape_pad.append(res - mod)
            shape_trim.append(0)
        # --- If overflow < half of resolution ==> trim
        else:
            shape_trim.append(mod)
            shape_pad.append(0)

    # (1) Trim volume
    trims = []
    for ax, shape in enumerate(shape_trim):
        if shape > 0:
            s = [slice(0, i, 1) for i in vol.shape]
            s[ax] = slice(vol.shape[ax] - shape, vol.shape[ax], 1)
            trims.append(vol[s].ravel())
    if len(trims) > 0:
        trim = np.concatenate(trims, axis=0)
        vol = vol[[slice(0, s - t, 1) for s, t in zip(vol.shape, shape_trim)]]
    else:
        trim = np.array([], dtype=vol.dtype)

    # (2) Pad volume
    pad_array = [(0, s) for s in shape_pad]
    vol = np.pad(vol, pad_array, mode='constant', constant_values=np.min(vol))

    return vol, shape_pad, shape_trim, trim

def load_old(filename, infos={}, init_infos_only=False):
    """
    Method to load *.mvk file

    """
    # --- Load header and kernel
    header, kernel, offset = load_header_kernel(filename)

    # --- Validate
    infos = init_infos(infos, header)
    infos = validate_infos(infos)

    # --- Determine scale of reconstruction (range along FIRST axis of stacked) 
    kernel_sub, kernel_sub_indices = create_reconstruction_kernel(header, infos, kernel)

    # --- Determine affine indices and reconstruction shape 
    affine_indices = determine_affine_indices(header, infos, kernel_sub)

    # --- Determine bounds for reconstruction (range along REMAINING axes of stacked)
    bounds, paddings = create_reconstruction_bounds(header, infos, kernel_sub)

    # --- Exit early if purpose is simply to initialize the infos dictionary
    infos['header'] = header
    if init_infos_only:
        return

    # --- Load mmap
    mmap = np.memmap(filename, mode='r', dtype=header['dtype'], offset=offset, shape=tuple(header['shape_vol']))

    # --- Reconstruct image based on kernel_sub, bounds and paddings 
    vol = reconstruct_image(mmap, header, kernel_sub_indices, bounds, paddings)

    # --- Finalize volume
    if infos['full_res']:
        e = np.prod(header['shape_vol']) * np.array([0], dtype=header['dtype']).itemsize
        trim = np.memmap(filename, mode='r', dtype=header['dtype'], offset=offset + int(e))
        vol = remove_pad_trim(vol, trim, header)

    # --- TODO: Apply fancying indexing (affines, etc)
    if affine_indices.size > 0:
        vol = vol[affine_indices[0], affine_indices[1], affine_indices[2], affine_indices[3]]

    return np.moveaxis(vol.astype('int16'), 0, -1), header

def remove_pad_trim(vol, trim, header):
    """
    Method to remove padding and trimming

    """
    # --- Remove padding
    for ax, shape in enumerate(header['shape_pad']):
        if shape > 0:
            selection = [slice(0, s, 1) for s in vol.shape]
            selection[ax] = slice(0, vol.shape[ax] - shape, 1)
            vol = vol[selection]

    # --- Add trimming
    if trim.size > 0:
        pad_array = [(0, s) for s in header['shape_trim']]
        vol = np.pad(vol, pad_array, mode='constant')
        offset = 0
        for ax, shape in enumerate(header['shape_trim']):
            if shape > 0:
                selection = [slice(0, s, 1) for s in vol.shape]
                selection[ax] = slice(vol.shape[ax] - shape, vol.shape[ax], 1)
                end = offset + vol[selection].size
                vol[selection] = trim[offset:end].reshape(vol[selection].shape)
                offset = end

    return vol
