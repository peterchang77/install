import os, shutil, subprocess
from jarvis.utils import pacs as jpacs
from jarvis.utils.general import tools as jtools, printd

# =======================================================================
# USAGE MESSAGES
# =======================================================================

USAGE_PACS = """
USAGE: jarvis pacs [SUBCOMMAND] (...)

Jarvis PACS query / retreive tool 

SUBCOMMANDS:

  configs           Display server configurations
  env               Display Jarvis PACS environment vars
  find              Perform C-FIND command
  move              Perform C-MOVE command
  batch             Perform batch of C-MOVE commands
  queue             Display status of queue
  status            Display status of batch
  delete            Delete request (including all pending)
  daemon            Manually launch PACS daemon
  storescp          Manually launch DICOM STORE-SCP reciever
  time              Manually set time zone
  init              Initialize default config files
  install           Install JRE and DICOM reciever

OPTIONS:

  -host             Remote PACS server host
  -port_called      Remote PACS server port
  -port_calling     Local listening port
  -aet_calling      Local listening AE Title
  -aet_called       Remote PACS AE Title

Note that default PACS server configs can be set via ENV variables.

QUERY/RETREIVE:

  -tag (KEY=VALUE)  DICOM tag value (e.g. jarvis pacs -tag AccessionNumber=...)
  -csv              Use *.csv file with key-value pairs
  -yml              Use *.yml with custom download rules 
  -output_dir       Output directory
  -output_csv       Output *.csv file for results 

BATCH OPERATIONS:

  -name             Name of request (for batch, status, delete and clear)

EXAMPLES

$ jarvis pacs find -tag KEY=VALUE   ==> perform C-FIND operation with specified KEY=VALUE tag 
$ jarvis pacs move -tag KEY=VALUE   ==> perform C-MOVE operation with specified KEY=VALUE tag 
$ jarvis pacs status                ==> display status of all requests
$ jarvis pacs status -name req-00   ==> display status of "req-00" request
$ jarvis pacs delete -name req-00   ==> delete "req-00" (including all pending)

"""
# =======================================================================

def pacs(subcommand=None, **kwargs):

    if subcommand is None:
        print(USAGE_PACS)
        return

    FUNCS = {
        'init': pacs_init,
        'time': pacs_time,
        'install': pacs_install}

    if subcommand in FUNCS:
        FUNCS[subcommand](**kwargs)
        return

    # --- Remaining commands require PACS client

    update_server(**kwargs)
    kwargs = parse_tag_to_query(**kwargs)
    client = jpacs.PACSClient()

    FUNCS = {
        'daemon': pacs_daemon,
        'storescp': pacs_storescp,
        'status': pacs_status,
        'queue': pacs_queue,
        'delete': pacs_delete,
        'configs': pacs_configs,
        'env': pacs_env,
        'batch': pacs_batch,
        'find': pacs_find,
        'move': pacs_move}

    if subcommand in FUNCS:
        FUNCS[subcommand](client, **kwargs)
        return

# =======================================================================
# DECORATORS AND HELPERS
# =======================================================================

def needs_query_or_csv(func):

    def wrapper(*args, **kwargs):

        if (kwargs.get('query', None) or kwargs.get('csv', None)) is None:

            print('ERROR either -query or -csv_file must be set')
            print(USAGE_PACS)

            return

        func(*args, **kwargs)

    return wrapper

def update_server(**kwargs):

    for key in ['host', 'port_called', 'port_calling', 'aet_called', 'aet_calling']:
        if kwargs.get(key, None) is not None:
            os.environ['JARVIS_PACS_{}'.format(key.upper())] = kwargs.pop(key)

def parse_tag_to_query(tag=None, **kwargs):

    if tag is not None:
        assert '=' in tag, 'ERROR -tag must contain "=", jarvis pacs -tag KEY=VALUE'
        kwargs['query'] = {tag.split('=')[0]: [tag.split('=')[1]]}

    return kwargs

# =======================================================================
# METHODS 
# =======================================================================

def pacs_init(**kwargs):

    import pkg_resources

    configs = jtools.find_configs_dir()

    for key in ['anons', 'pacsd']:

        dst = '{}/{}.yml'.format(configs, key)

        if os.path.exists(dst):
            if input('Rewrite existing {} with default (Y/n)? '.format(dst)) != 'Y':
                return

        src = pkg_resources.resource_filename('jarvis_pacs', 'ymls/{}.yml'.format(key)) 
        shutil.copy(src=src, dst=dst)
        print('Created default {} file'.format(dst))

def pacs_install(**kwargs):

    if input('Installing JRE and DICOM receiever, recommend running as root with $HOME var set, continue (Y/n)? ') != 'Y':
        return

    import pkg_resources

    scripts = '{}/scripts/install.sh'.format(os.path.dirname(pkg_resources.resource_filename('jarvis_pacs', '')))
    subprocess.call(scripts)

def pacs_time(**kwargs):

    subprocess.call(['apt-get', 'update'])
    subprocess.call(['apt-get', 'install', 'tzdata'])

def pacs_daemon(client, **kwargs):

    client.print_configs()
    pacsd = jpacs.PACSDaemon()
    pacsd.start()

def pacs_storescp(client, **kwargs):

    client.print_configs()

    dcm4che = os.environ.get('DCM4CHE_HOME', None) 
    if dcm4che is None:
        dcm4che = '{}/dcm4che'.format(os.environ['HOME'])

    cmd = [
        '{}/bin/storescp'.format(dcm4che),
        '-b',
        '{}:{}'.format(client.server['aet_calling'], client.server['port_calling']),
        '--directory',
        client.ENV['PACS_PATH_DOWNLOAD'],
        '--filepath',
        '{0020000d}/{00080018}.dcm'
    ]

    printd('')
    printd('Jarvis PACS | DICOM-SCP receiver (dcm4che)')
    printd(' '.join(cmd))
    printd('')
    subprocess.call(cmd)

def pacs_configs(client, **kwargs):

    client.print_configs()

def pacs_env(client, **kwargs):

    client.print_env(prefix='PACS_')

def pacs_status(client, name=None, **kwargs):

    client.status_imports_csv(pattern=name)

def pacs_queue(client, **kwargs):

    pacsd = jpacs.PACSDaemon()
    pacsd.status_queue()

def pacs_delete(client, name=None, **kwargs):

    client.delete_request(name=name, dirs=['parse', 'queue', 'comps'])

@needs_query_or_csv
def pacs_find(client, query=None, csv=None, output_csv=None, **kwargs):

    print('Jarvis PACS | Performing C-FIND ({})'.format(query or csv_file))
    results = client.perform_find(query=query, csv_file=csv)
    if output_csv is not None:
        results.to_csv(output_csv, index=False)
    else:
        print(results)

@needs_query_or_csv
def pacs_move(client, query=None, csv=None, output_dir=None, **kwargs):

    print('Jarvis PACS | Performing C-MOVE ({}) ==> {}'.format(query or csv_file, output_dir or client.ENV['PACS_PATH_DOWNLOAD']))
    client.perform_move(query=query, csv_file=csv, output_dir=output_dir)

@needs_query_or_csv
def pacs_batch(client, name=None, query=None, csv=None, yml=None, **kwargs):

    print('Jarvis PACS | Submitting batch job ==> {}'.format(client.requests['parse']))
    client.create_request(name=name, query=query, csv_file=csv, yml_file=yml)
