import os, glob, shutil, time, json, pandas as pd
import gdcm
from jarvis.utils.general import Base, printr, printd

# ================================================================== 
# GLOBAL VARIABLES
# ================================================================== 

TAGS = {
    'PatientID': [0x0010, 0x0020],
    'AccessionNumber': [0x0008, 0x0050],
    'StudyDate': [0x0008, 0x0020],
    'StudyDescription': [0x0008, 0x1030],
    'PatientAge': [0x0010, 0x1010],
    'Modality': [0x0008, 0x0060],
    'BodyPartExamined': [0x0018, 0x0015],
    'ReferringPhysicianName': [0x0008, 0x0090],
    'AdditionalPatientHistory': [0x0010, 0x21b0],
    'StudyInstanceUID': [0x0020, 0x000d],
    'SeriesInstanceUID': [0x0020, 0x000e],
    'SOPInstanceUID': [0x0008, 0x0018]}

# --- Template query dictionary
QUERY = {k: '*' for k in TAGS}

# ================================================================== 
# GDCM TAG MANIPULATION 
# ================================================================== 

TAGS_GDCM = lambda key : gdcm.Tag(*TAGS[key])

def set_tag(ds, tag, value):
    """
    Set tag with value and insert into ds

    """
    de = gdcm.DataElement(TAGS_GDCM(tag))
    de.SetByteValue(value, gdcm.VL(len(value)))
    ds.Insert(de)

    return ds

def create_ds(query):

    # --- Create ds
    ds = gdcm.DataSet()
    for tag, value in query.items():
        ds = set_tag(ds=ds, tag=tag, value=value)

    return ds

# ================================================================== 
# DISME OPERATIONS (C-FIND, C-MOVE) 
# ================================================================== 

def perform_find(configs, query={}, results=None, root_model='patient'):
    """
    Method to perform PACS query

    :params

      (dict) configs : a configuration dictionary for PACS server information 
      (dict) query   : a query dictionary
      (dict) results : if provided, append current query result to existing results

    :return

      (dict) results

    """
    # --- Create query
    query = {**QUERY, **query}

    # --- Create results
    results = results or {k: [] for k in query}

    # --- Create ds
    ds = create_ds(query)

    # --- Configure query object 
    cnf = gdcm.CompositeNetworkFunctions()
    rmd = gdcm.eStudyRootType if root_model == 'study' else gdcm.ePatientRootType
    theQuery = cnf.ConstructQuery(rmd, gdcm.eStudy, ds)

    # --- Prepare the variable for output
    ret = gdcm.DataSetArrayType()
    
    # --- Perform query
    cnf.CFind(
        configs['host'],            # gdcm ==> 'remote'
        configs['port_called'],     # gdcm ==> 'portno'
        theQuery, 
        ret, 
        configs['aet_calling'],     # gdcm ==> 'aetitle'
        configs['aet_called']       # gdcm ==> 'call'
    )

    # --- Save to dictionary 
    for i in range(len(ret)):
        for tag in query:
            value = str(ret[i].GetDataElement(TAGS_GDCM(tag)).GetValue())
            results[tag].append(value)

    return results

def perform_move(configs, query={}, output_dir='./', verbose=False, root_model='patient'):
    """
    Method to perform C-MOVE

    """
    # --- Create ds query
    ds = create_ds(query)

    # --- Configure query object 
    cnf = gdcm.CompositeNetworkFunctions()
    rmd = gdcm.eStudyRootType if root_model == 'study' else gdcm.ePatientRootType
    theQuery = cnf.ConstructQuery(rmd, gdcm.eStudy, ds, True)

    # --- Perform move
    cnf.CMove(
        configs['host'],            # gdcm ==> 'remote'
        configs['port_called'],     # gdcm ==> 'portno'
        theQuery, 
        configs['port_calling'],    # gdcm ==> 'portscp'
        configs['aet_calling'],     # gdcm ==> 'aetitle'
        configs['aet_called'],      # gdcm ==> 'call'
        output_dir
    )

# ================================================================== 
# PACSClient 
# ================================================================== 

def find_requests_dirs():
    """
    Method to find directories used for PACS client and daemons

      {JARVIS_PACS_PATH_REQUESTS}/parse
      {JARVIS_PACS_PATH_REQUESTS}/queue
      {JARVIS_PACS_PATH_REQUESTS}/comps

    Note, {JARVIS_PACS_PATH_REQUESTS} is commonly {JARVIS_HUB_STORE}/reqs

    """
    dirs = ['parse', 'queue', 'comps']
    reqs = os.environ.get('JARVIS_PACS_PATH_REQUESTS', '')

    requests = {d: '{}/{}'.format(reqs, d) for d in dirs}

    # --- Find default request.yml file
    requests['default-yml'] = '{}/ymls/request.yml'.format(os.path.dirname(__file__))

    return requests

def init_imports_csv(cols=['uid', 'iid', 'tag', 'fnames', 'dtype', 'db', 'json'], **kwargs):

    # --- Set defaults
    DEFAULTS = {
        'iid': os.environ.get('JARVIS_HUB_INSTITUTION_ID', 'default_iid'),
        'dtype': 'dat',
        'db': 'orig'}

    kwargs = {**DEFAULTS, **kwargs}

    # --- Create DataFrame
    return pd.DataFrame.from_dict({c: kwargs.get(c, '') for c in cols})

class PACSClient(Base):

    def __init__(self):

        # --- Initialize
        self.load_configs(names=['pacsd'])
        self.init_directories()

        # --- Create server configs
        keys = [
            'PACS_HOST', 
            'PACS_PORT_CALLED', 
            'PACS_PORT_CALLING', 
            'PACS_AET_CALLED', 
            'PACS_AET_CALLING',
            'PACS_ROOT_MODEL']

        self.server = {k[5:].lower(): self.ENV[k] for k in keys}
        self.server['port_called'] = int(self.server['port_called'])
        self.server['port_calling'] = int(self.server['port_calling'])

    def init_directories(self):
        """
        Method to find and initialize directories

        """
        os.makedirs(self.ENV['PACS_PATH_DOWNLOAD'], exist_ok=True)

        self.requests = find_requests_dirs() 
        for k, d in self.requests.items():
            if k in ['parse', 'queue', 'comps']:
                os.makedirs(d, exist_ok=True)

    def load_df(self, query=None, csv_file=None):

        if type(query) is pd.DataFrame:
            return query

        assert query or csv_file is not None

        if csv_file is not None:
            return pd.read_csv(csv_file, dtype='str')

        if query is not None:

            return pd.DataFrame.from_dict(query)

    def perform_find(self, query=None, csv_file=None):
        """
        Method to perform serial C-FIND operations of provided queries

        """
        df = self.load_df(query, csv_file)

        results = None
        for n, row in df.iterrows():
            results = perform_find(configs=self.server, query=row.to_dict(), results=results, root_model=self.server['root_model'])

        results = pd.DataFrame.from_dict(results)

        return results

    def perform_move(self, query=None, csv_file=None, output_dir=None, verbose=False):
        """
        Method to perform serial C-MOVE operations of provided queries

        """
        df = self.load_df(query, csv_file)

        for n, row in df.iterrows():

            query = row.to_dict()
            subdir = self.get_query_output_subdir(query, output_dir=output_dir, makedirs=True)
            
            if verbose:
                printr('Performing C-MOVE ({:03d}/{:03d}) | {}'.format(n + 1, df.shape[0], os.path.basename(subdir)))

            perform_move(configs=self.server, query=query, output_dir=subdir, root_model=self.server['root_model'])

        return df

    def get_query_output_subdir(self, query, output_dir=None, makedirs=False):
        """
        Method to get [output_dir]/[output_subdir] where:

          * output_dir    ==> provided, else defaults to self.ENV['PACS_PATH_DOWNLOAD']
          * output_subdir ==> StudyInstanceUID from query, else first key-value pair in query

        """
        output_dir = output_dir or self.ENV['PACS_PATH_DOWNLOAD'] 
        subdir = '{}/{}'.format(output_dir, query.get('StudyInstanceUID', next(iter(query.values()))))

        if makedirs:
            os.makedirs(subdir, exist_ok=True)

        return subdir

    # =======================================================================
    # BATCH OPERATIONS (INTERFACE FOR PACS DAEMON)
    # =======================================================================

    def create_request(self, name=None, query=None, csv_file=None, yml_file=None):
        """
        Method to create C-MOVE job request to download/reqs/pend

        """
        name = name or os.path.basename(csv_file or '')[:-4] or 'req-{}'.format(str(time.time()).replace('.', '-'))
        csv = '{}/{}.csv'.format(self.requests['parse'], name)
        yml = '{}/{}.yml'.format(self.requests['parse'], name)

        # --- Copy *.csv file
        if csv_file is not None:
            shutil.copy(src=csv_file, dst=csv)

        else:
            query = pd.DataFrame.from_dict(query)
            query.to_csv(csv, index=False)

        # --- Copy *.yml file
        yml_file = yml_file or self.requests['default-yml'] 
        shutil.copy(src=yml_file, dst=yml)

    def delete_request(self, name, dirs=['parse', 'queue', 'comps'], delete_imports_csv=True):

        if name is None:
            print('ERROR a name must be provided to remove request')
            return

        for d in dirs:
            fnames = glob.glob('{}/{}*'.format(self.requests[d], name))
            for fname in fnames:
                print('Deleting: {}'.format(fname))
                os.remove(fname)

        if delete_imports_csv:
            csvs = glob.glob(self.get_imports_csv(name=name))
            for csv in csvs:
                df = self.load_csv(csv)
                for p in df['fnames']:
                    dcms = glob.glob(p)
                    if len(dcms) == 0:
                        ds = os.path.dirname(p)
                        ds = glob.glob(ds + '/')
                        for d in ds:
                            shutil.rmtree(d)
                            print('Deleting: {}'.format(d))

                os.remove(csv)
                print('Deleting: {}'.format(csv))

    def get_imports_csv(self, name=None, req=None):

        name = name or os.path.basename(req['csv']).split('.part-')[0]

        return '{}/imports_{}.csv'.format(self.ENV['PACS_PATH_DOWNLOAD'], name)

    def create_imports_csv(self, df, req):
        """
        Method to create imports_[req].csv

        """
        # --- Find target glob.glob('*.dcm') fnames 
        fnames = ['{}/*.dcm'.format(self.get_query_output_subdir(row.to_dict())) 
            for n, row in df.iterrows()]

        # --- Create DataFrame
        j = json.dumps(self.load_yml(req['yml']))
        df = init_imports_csv(fnames=fnames, json=j)

        # --- Get target CSV
        csv = self.get_imports_csv(req=req)
        if os.path.exists(csv):
            df = pd.concat((self.load_csv(csv), df))

        df.to_csv(csv, index=False)

        return csv 

    def status_imports_csv(self, pattern=None):
        """
        Method to display status of downloads based on available imports*.csv files

        """
        csvs = glob.glob('{}/imports_*{}.csv'.format(self.ENV['PACS_PATH_DOWNLOAD'], pattern or ''))

        printd('')
        printd('Jarvis PACS | Download status report')
        printd('')

        for csv in csvs:

            df = self.load_csv(csv)

            printd('  ' + '=' * 100)
            printd('  CSV FILE: {}'.format(csv))
            printd('  ' + '-' * 100)

            total = 0
            found = 0
            for p in df['fnames']:
                dcms = glob.glob(p)
                printd('  {path: <80} | {count}'.format(path=p.split('/')[-2], count=len(dcms)))
                total += len(dcms)
                if len(dcms) > 0:
                    found += 1

            printd('  ' + '-' * 100)
            p = 'TOTAL DOWNLOADED {:05d} / {:05d}'.format(found, df.shape[0])
            printd('  {path: <80} | {count}'.format(path=p, count=total))

        printd('')

    def print_configs(self):

        printd('')
        printd('Jarvis PACS | Server configurations')
        printd('')

        printd('  {key: <25} {url}'.format(key='ENV VAR', url='VALUE'))
        printd('  ' + '-' * 100)
        for key, value in self.server.items():
            printd('  {key: <25} {value}'.format(key=key, value=value))
        printd('  ' + '-' * 100)
        printd('')
