import os, glob, shutil, copy, json, time
from jarvis.utils.general import sha1, recursive_set, printd
from jarvis.utils import io, arrays as jars
from jarvis_dicom import load_multiseries, read_headers

class JarvisStudy():

    def __init__(self, doc=None, root='', load=None, save=None, **kwargs):

        # --- Init paramaters 
        self.load = load
        self.save = save
        self.root = root

        # --- Init trash bin
        self.trash = '{}/.trash'.format('/'.join(self.root.split('/')[:-2]))

        # --- Expand to absolute paths
        if root != '' and doc is not None:
            doc = self.to_abs_path(doc=doc) 

        # --- Initialize doc
        self.init_attrib(doc, **kwargs)

    def refresh_status(self):
        
        self.study['status'] = {**self.study['status'], 
            **{'updated_at': time.time(), 'recent': True}}

    def init_attrib(self, doc, **kwargs):

        doc = doc or {}

        # --- Stratify dicts by _hash-*
        for n, h in zip(
            ['arrays', 'series', 'coords', 'fviews'],
            ['unique', 'series', 'coords', 'fviews']):

            h = '_hash-{}'.format(h)

            dicts = kwargs.get(n, None) or doc.get(n, None) or []

            setattr(self, n, {d[h]: d for d in dicts if h in d})

        # --- Set study
        self.study = kwargs.get('study', None) or doc.get('study', {})

        if 'status' not in self.study:
            self.study['status'] = {}

        # --- Set _id
        self._id = doc.get('_id', None)

    def remap_headers(self, d):
        """
        Method to remap current headers to new values (based on provided dict)

        :params

          (dict) d : new mappings = {

            'pid': {
                old_value_00: new_value_00,
                old_value_01: new_value_01, ...}, 
            'sid': ...,
            'study_uid': ..., 
            'series_uid': ...,

          }

        """
        remap = lambda obj, d : {k: d[k].get(v, None) if k in d else v for k, v in obj.items()}

        # --- Remap study.study
        self.study = remap(self.study, d) 

        # --- Remap in study['header']
        self.study['header'] = remap(self.study['header'], d) 

        # --- Remap in series['header']
        for series in self.series.values():
            series['header'] = remap(series['header'], d) 

    def add_array(self, arr=None, fname=None, hash_series=None, **kwargs):
        """
        Method to add JarvisArray to current study object

        """
        arrs = {}

        if hash_series is not None and type(fname) is list:

            # --- Find all existing files in series
            s = self.find_arrays(hash_series=hash_series)
            e = [f for unique in s for f in self.arrays[unique]['fname']] 

            e = {k: v[0] for k, v in read_headers(e, pattern=['SOPInstanceUID']).items()}
            f = {k: v[0] for k, v in read_headers(fname, pattern=['SOPInstanceUID']).items()}

            n = [v for k, v in f.items() if k in e]

            # --- No new files
            if len(n) == len(f):
                self.study['import-trash'] += fname
                return arrs 

            if len(n) > 0:
                self.study['import-trash'] += n

            for unique in s:
                self.del_array(hash_unique=unique)

            fname = {**f, **e}
            fname = list(fname.values())

        # --- Add arrays (multiple DICOMs)
        if  (type(fname) is list) or \
            (type(fname) is str and fname[-1] == '/') or \
            (type(fname) is str and fname[-4] == '.dcm'):

            series = load_multiseries(fname)

            for v in series.values():

                arr = jars.create(**v)
                arrs.update(self.add_array_single(arr, fname=v['meta']['fnames-orig']))

            return arrs

        # --- Add array (single)
        arr = arr or self.load_array(fname, **kwargs)
        arrs = self.add_array_single(arr, fname=fname)

        return arrs

    def add_array_single(self, arr, fname=None):

        u = arr.to_json()

        # --- (1) If hash_unique already exists, ignore
        if u['arrays']['_hash-unique'] in self.arrays:
            printd('Repeated: {}'.format(u['arrays']['_hash-unique']))
            self.study['import-trash'].extend(fname) if type(fname) is list else self.study['import-trash'].append(fname)
            return {}

        u['arrays']['fname'] = fname 

        for n, h in zip(
            ['arrays', 'series', 'coords', 'fviews'],
            ['unique', 'series', 'coords', 'fviews']):

            h = '_hash-{}'.format(h)

            if u[n][h] not in getattr(self, n):
                getattr(self, n)[u[n][h]] = u[n]

        # --- Update study
        recursive_set(self.study, u['study'])

        return {u['arrays']['_hash-unique']: arr}

    def del_array(self, arr=None, hash_unique=None, **kwargs):

        hash_unique = hash_unique or arr.attrib._hash_unique

        if hash_unique not in self.arrays:
            return

        arrays_dict = self.arrays.pop(hash_unique)

        for k in ['series', 'coords', 'fviews']:
            h = '_hash-{}'.format(k)
            if h in arrays_dict:
                value = arrays_dict[h] 
                kwargs = {h[1:]: value}
                matches = self.find_arrays(**kwargs)
                if len(matches) == 0:
                    getattr(self, k).pop(value)

    def get_array(self, arr=None, hash_unique=None, **kwargs): pass

    def load_array(self, fname, load=None, **kwargs):
        """
        Method to load fname as JarvisArray 

        """
        load = load or self.load or io.load

        ret = load(fname)

        if type(ret) is tuple:
            data, meta = ret
        else:
            data = ret
            meta = None

        if data is None:
            return jars.create(fname)

        return jars.create(data=data, meta=meta)

    def save_array(self, arr, fname, **kwargs):
        """
        Method to save JarvisArray

        """
        pass

    def new(self, doc=None, load=None, save=None, **kwargs):

        doc = doc or self.to_json()
        load = load or self.load
        save = save or self.save

        return Study(doc=doc, load=load, save=save, **kwargs)

    def find(self, **kwargs): pass

    def find_orientation(self, orient='AXI'): pass

    def find_slices(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_mu(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_sd(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_modality(self): pass

    def find_contrast(self): pass

    def find_arrays(self, **kwargs):

        matched = lambda h, value : set([k for k, v in self.arrays.items() if v.get(h, None) == value])
        matches = set(self.arrays.keys())

        for h, value in kwargs.items():

            h = '_' + h.replace('_', '-')
            matches = matches & matched(h, value)

        return matches

    def add_import_matching(self, pattern, recursive=True, **kwargs):
        """
        Method to add files to self.study['import'] based on search pattern 

        """
        fnames = glob.glob(pattern, recursive=recursive)

        if len(fnames) > 0:
            ext = fnames[0].split('.')[-1]

            if ext in ['dcm']:

                d = read_headers(fnames)
                assert len(d) == 1, 'ERROR more than one StudyInstanceUID found'
                self.add_import(next(iter(d.values())))

            else:

                d = {f: f for f in fnames}
                self.add_import(d)

    def add_import(self, d):
        """
        Method to recursively add files into self.study['import']
        
        :return

          (bool) status : True if updated, else False

        """
        if 'import' not in self.study:
            self.study['import'] = {}

        # --- Determine number total files
        count = lambda : sum([len(v) for v in self.study['import'].values()])
        n = count()

        # --- Update
        d = {sha1(str(k), truncate=10): v for k, v in d.items()}
        recursive_set(self.study['import'], d)

        # --- Remove redundant elements 
        self.study['import'] = {k: list(set(v)) if type(v) is list else [v] for k, v in self.study['import'].items()}

        return count() > n

    def run_import(self, pattern=None, save_files=False, move_files=False, copy_files=False, load=None, verbose=False, **kwargs):
        """
        Method to run import based on files in self.study['import']

        """
        if pattern is not None:
            self.add_import_matching(pattern, **kwargs)

        if 'import' not in self.study:
            return

        if verbose:
            printd('Importing: {}'.format(self.study['uid']))

        arrays_dicts = []
        self.study['import-trash'] = []

        for hash_series, fname in self.study['import'].items():

            arrs = self.add_array(fname=fname, load=load, hash_series=hash_series)

            for unique, arr in arrs.items():
                arrays_dicts.append(self.arrays[unique])
                if save_files:
                    self.save_files(arrs=[arr], **kwargs)

        if copy_files:
            self.copy_files(arrays_dicts=arrays_dicts, **kwargs)

        if move_files:
            self.move_files(arrays_dicts=arrays_dicts, **kwargs)

        self.study.pop('import')

        # --- Trash
        for fname in self.study['import-trash']:
            self.move_to_trash(fname)

        self.study.pop('import-trash')

    def copy_files(self, dst_dir=None, arrays_dicts=None, symlink=False, hash_unique=True, **kwargs):
        """
        Method to copy (or symlink) files to new dst

        """
        func = os.link if symlink else shutil.copy
        self._copy_or_move_files(func, dst_dir, arrays_dicts, hash_unique, **kwargs)

    def move_files(self, dst_dir=None, arrays_dicts=None, hash_unique=True, **kwargs):
        """
        Method to move files to new dst

        """
        self._copy_or_move_files(shutil.move, dst_dir, arrays_dicts, hash_unique, **kwargs)

    def save_files(self, dst_dir=None, arrays_dicts=None, arrs=None, **kwargs):
        """
        Method to save files 

        By default, self.root is the dst_dir (unless manually specified)

        """
        # --- Find arrs to save 
        arrs = arrs or arrays_dicts or list(self.arrays.values())
        if type(arrs) is not list:
            arrs = [arrs]

        # --- Create dst_dir
        dst_dir = dst_dir or self.root or './'
        if dst_dir[-1] != '/':
            dst_dir = dst_dir + '/'

        for arr in arrs:

            if type(arr) is dict:
                arr = self.load_array(arr['fname'], **kwargs)

            unique = arr.attrib._hash_unique

            if hasattr(arr, 'to_hdf5'):
                dst = '{}{}.hdf5'.format(dst_dir, unique)
                arr.to_hdf5(dst)

            else:
                dst = '{}{}.json'.format(dst_dir, unique)
                arr.to_hdf5(dst)

            # --- Update new fname
            self.arrays[unique]['fname'] = dst

    def _copy_or_move_files(self, func, dst_dir, arrays_dicts=None, hash_unique=True, **kwargs):
        """
        Method to copy or move files

        """
        # --- Find arrays_dicts to move
        arrays_dicts = arrays_dicts or list(self.arrays.values())
        if type(arrays_dicts) is not list:
            arrays_dicts = [arrays_dicts]

        for arrays_dict in arrays_dicts: 

            src = arrays_dict['fname']
            dst = None

            if type(src) is str:
                dst = self._copy_or_move_files_single(src, func, dst_dir, arrays_dict, hash_unique, **kwargs)
                
            elif type(src) is list:

                dst = []
                pnd = []

                # --- Identify files already in dst_dir
                for s in src:
                    base = self._create_dst_base_ext(s, dst_dir, arrays_dict, hash_unique)[0]
                    dst.append(s) if s[:len(base)] == base else pnd.append(s)

                # --- Move pending files
                for s in pnd:
                    d = self._copy_or_move_files_single(s, func, dst_dir, arrays_dict, hash_unique, len(dst), **kwargs)
                    dst.append(d)

            # --- Update new fname
            self.arrays[arrays_dict['_hash-unique']]['fname'] = dst

    def _copy_or_move_files_single(self, src, func, dst_dir, arrays_dict, hash_unique, index=None, overwrite=False):

        if not os.path.exists(src):
            return 

        # --- Create dst components
        dst_base, ext = self._create_dst_base_ext(src, dst_dir, arrays_dict, hash_unique)
        index = '-{:05d}'.format(index) if type(index) is int else ''

        # --- Create dst
        dst = '{}{}{}'.format(dst_base, index, ext)

        # --- Overwrite
        if os.path.exists(dst) and not overwrite:
            index = index + 1 if type(index) is int else 0
            return self._copy_or_move_files_single(src, func, dst_dir, arrays_dict, hash_unique, index)

        os.makedirs(os.path.dirname(dst), exist_ok=True)
        func(src=src, dst=dst)

        return os.path.abspath(dst) 

    def _create_dst_base_ext(self, src, dst_dir, arrays_dict, hash_unique):

        uniq =  arrays_dict['_hash-unique'] if hash_unique else None
        base, ext = os.path.splitext(os.path.basename(src))
        base = uniq or base

        dst_dir = dst_dir or self.root or './'
        if dst_dir[-1] != '/':
            dst_dir = dst_dir + '/'

        return '{}{}'.format(dst_dir, base), ext

    def move_to_trash(self, src):

        os.makedirs(self.trash, exist_ok=True)
        dst = '{}/{}'.format(self.trash, os.path.basename(src))
        shutil.move(src=src, dst=dst)

    def to_abs_path(self, fname=None, doc=None):

        if doc is not None:
            if 'arrays' in doc:
                for i in range(len(doc['arrays'])):
                    doc['arrays'][i]['fname'] = self.to_abs_path(doc['arrays'][i]['fname']) 
            return doc

        fname = fname or ''

        if type(fname) is str:
            return '{}{}'.format(self.root, fname)

        if type(fname) is list:
            return [self.to_abs_path(f) for f in fname]

    def to_rel_path(self, fname=None, doc=None):

        if doc is not None:
            if 'arrays' in doc:
                for i in range(len(doc['arrays'])):
                    doc['arrays'][i]['fname'] = self.to_rel_path(doc['arrays'][i]['fname']) 
            return doc

        fname = fname or ''

        if type(fname) is str:
            return fname.replace(self.root, '', 1)

        if type(fname) is list:
            return [self.to_rel_path(f) for f in fname]

    def to_new_root(self, root):
        """
        Method to convert document contents to new root

        """
        # --- To relative paths (del old root)
        doc = {'arrays': list(self.arrays.values())}
        doc = self.to_rel_path(doc=doc)

        # --- To absolute paths (add new root)
        self.root = root
        doc = self.to_abs_path(doc=doc)

        # --- Add to self.arrays
        self.arrays = {d['_hash-unique']: d for d in doc['arrays']} 

    def to_json(self, fname=None, to_rel_path=True):

        self.refresh_status()

        # --- Create doc
        doc = {}
        if self._id is not None:
            doc['_id'] = self._id
        doc['study'] = self.study
        for k in ['arrays', 'series', 'coords', 'fviews']:
            doc[k] = copy.deepcopy(list(getattr(self, k).values()))

        # --- Relative fnames
        if to_rel_path:
            doc = self.to_rel_path(doc=doc)

        # --- Serialize
        if fname is not None:
            os.makedirs(os.path.dirname(fname), exist_ok=True)
            json.dump(unique_dict, open(fname, 'w'))

        return doc
