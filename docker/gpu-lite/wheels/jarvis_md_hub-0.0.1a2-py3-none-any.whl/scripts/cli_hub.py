import os, shutil, getpass
from jarvis.utils import hub as jhub
from pprint import pprint

# =======================================================================
# USAGE MESSAGES
# =======================================================================

USAGE_HUB = """
USAGE: jarvis hub [SUBCOMMAND] (...)

Jarvis Hub command-line tool 

SUBCOMMANDS:

  start             Start daemon
  count             Display number of documents in db
  find              Find document
  remove            Remove document(s) from database
  drop              Drop collection in database
  clean             Manually (re-)anonymize exams
  quar              Analyze quarantined exams
  export            Export file(s) from db (specify query, uid or csv)

ADMIN

  init              Initialize hub 
  users             List all users
  user-add          Add new user
  user-drop         Drop current user
  clear-cache       Clear DICOM cache

OPTIONS:

  -name             Name of service 
  -db               MongoDB database name
  -collection       MongoDB collection name
  -query            MongoDB query
  -uid              UID (Jarvis identifier)
  -csv              CSV file

EXPORT OPTIONS:

  -output_dir       Output dir (default is ./export)
  -symlink          Create symlinks     

CLEAN OPTIONS:

  -quar             Name of quar rule
  -meta             Name of meta rule
  -burn             Name of burn rule

EXAMPLES:

$ jarvis hub find -query uid=1.2.3.4                    ==> perform MongoDB query for uid
$ jarvis hub clean -uid 1.2.3.4 -quar quar-default      ==> manually (re-)anonymize uid with quar rule
$ jarvis hub clean -csv req.csv -quar quar-default      ==> manually (re-)anonymize all studies in csv with quar rule
# jarvis hub quar -csv req.csv                          ==> analyze quarantined exams in req.csv
# jarvis hub quar -query study.uid=*                    ==> analyze quarantined exams by query 
$ jarvis hub export -query study.uid=1.2.3.4 -db orig   ==> export uid via query from orig db
$ jarvis hub export -uid 1.2.3.4 -db orig               ==> export uid from orig db
$ jarvis hub export -csv req.csv -db orig               ==> export all studies in csv from orig db
$ jarvis hub export -csv req.csv -db anon               ==> export all studies in csv from anon db (by default will also create decrypt.csv)

"""
# =======================================================================

def hub(subcommand=None, **kwargs):

    if subcommand is None:
        print(USAGE_HUB)
        return

    # --- Process kwargs
    to_query = lambda query : {query.split('=')[0]: query.split('=')[1]} if query is not None else {}
    kwargs['query'] = to_query(kwargs['query'])
    kwargs['symlink'] = bool(kwargs['symlink'])
    kwargs['output_dir'] = kwargs['output_dir'] or './export'

    FUNCS = {
        'init': hub_init,
        'users': hub_users,
        'user-add': hub_user_add,
        'user-drop': hub_user_drop,
        'clear-cache': hub_clear_cache,
        'start': hub_start,
        'count': hub_count,
        'find': hub_find,
        'remove': hub_remove,
        'drop': hub_drop,
        'clean': hub_clean,
        'quar': hub_quar,
        'export': hub_export}

    if subcommand in FUNCS:
        FUNCS[subcommand](**kwargs)

# =======================================================================
# DECORATORS AND HELPERS
# =======================================================================

def needs_client(func):

    def wrapper(db='orig', collection='dcm', *args, **kwargs):

        client = jhub.HubClient()
        client.use(db, collection, verbose=False)
        func(client=client, db=db, collection=collection, *args, **kwargs)

    return wrapper

def needs_anon(func):

    def wrapper(*args, **kwargs):

        client = jhub.AnonClient()
        kwargs['uid'] = find_uid(client=client, **kwargs)
        func(client=client, *args, **kwargs)

    return wrapper

def find_uid(client, uid=None, csv=None, query={}, **kwargs):

    if (uid or csv) is None:
        uid = [doc['study']['uid'] for doc in client.orig.find(query)]

    return uid

def hub_login():

    username = input('Username: ') 
    password = os.environ.get('JARVIS_SECRET', None) or getpass.getpass()

    return {'username': username, 'password': password}

# =======================================================================
# METHODS 
# =======================================================================

def hub_start(name=None, **kwargs):

    if name is None:
        print('ERROR name of service to start must be specified')
        return

    daemon = getattr(jhub, '{}Daemon'.format(name), None)()

    if daemon is None:
        print('ERROR specified service is not recognized')
        return

    daemon.start()

@needs_client
def hub_init(client, **kwargs):

    client.init_hub()

@needs_client
def hub_users(client, **kwargs):

    client.show_users()

@needs_client
def hub_user_add(client, **kwargs):

    print('Enter new credentials')
    client.add_hub_user(**hub_login())

@needs_client
def hub_user_drop(client, **kwargs):

    username = input('Enter username to drop: ')
    client.drop_hub_user(username)

@needs_client
def hub_count(client, **kwargs):

    client.count()

@needs_client
def hub_find(client, query={}, **kwargs):

    study = client.find_one_study(query)
    pprint(study.to_json())

@needs_client
def hub_remove(client, query={}, **kwargs):

    if query == {}:
        return

    studies = [s for s in client.find_study(query)]
    client.remove_studies(studies)

@needs_client
def hub_drop(client, db, collection, **kwargs):

    if input('Dropping: db = {} | collection = {}? (Y/n) '.format(db, collection)) == 'Y':
        if client.remove_studies(studies=client.find_study()):
            client.db.drop_collection(collection)

@needs_anon
def hub_clean(client, uid=None, csv=None, quar=None, meta=None, burn=None, **kwargs):

    client.manual_clean(uids=list(uid), req_csv=csv, quar=quar, meta=meta, burn=burn)

@needs_anon
def hub_quar(client, uid=None, csv=None, output_dir='./export', **kwargs):

    # --- Find uids
    dst_csv = '{}/quar.csv'.format(output_dir)
    df = client.find_quar_status(uids=list(uid), req_csv=csv, dst_csv=dst_csv)

    print('\rA total of {} / {} uids contain quarantined exams ==> See {} for more information'.format(
        len(set(df['uid'])),
        len(uid) if uid is not None else client.load_csv(csv).shape[0],
        dst_csv))

def hub_export(db='orig', *args, **kwargs):

    if db == 'anon': 
        hub_export_anon(db=db, **kwargs)
        return

    hub_export_orig(db=db, **kwargs)

@needs_anon
def hub_export_anon(client, uid=None, csv=None, output_dir='./export', symlink=True, **kwargs):

    client.export_studies(uids=list(uid), req_csv=csv, dst_dir=output_dir, symlink=symlink)

@needs_client
def hub_export_orig(client, uid=None, query={}, **kwargs):

    uid = find_uid(client, uid, csv, query)
    client.export_studies_by_uids(uids=list(uid), dst_dir=output_dir, symlink=symlink, **kwargs)

@needs_client
def hub_clear_cache(client, **kwargs):

    client.clear_cache(cache_name='hub-dicom-cache')

# =======================================================================
