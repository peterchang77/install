import time
from .study import JarvisStudy
from jarvis_mongo import MongoClient
from jarvis.utils.general import *

class HubClient(MongoClient):

    def init_custom(self, **kwargs):

        self.load_configs(name=['jhubd'])
        self.configs.update({'store': self.jhubd['store']})

    def init_server(self, host, port):

        return {
            'host': host or self.ENV['HUB_MONGO_HOST'] or '127.0.0.1',
            'port': port or self.ENV['HUB_MONGO_PORT'] or 27017}

    def get_root(self, uid):

        return '{}/{}/{}'.format(self.jhubd['store'], self.configs['db'], uid)

    def find_study(self, query=None):

        docs = self.find(query, no_cursor_timeout=True)

        try:
            for doc in docs:
                if len(doc) == 1 and '_id' in doc:
                    doc = self.find_one(doc)
                yield self.create_study(doc, query)

        except: pass
        finally:
            docs.close()

    def find_one_study(self, query=None):

        doc = self.find_one(query)

        return self.create_study(doc, query)

    def create_study(self, doc=None, query=None, truncate=10):

        if doc is None:
            doc = {}
            if query is not None:
                for k, v in query.items():
                    if type(v) is not dict:
                        recursive_set_with_keys(doc, keys=k.split('.'), value=v)

        if 'study' not in doc:
            doc['study'] = {}

        if 'uid' not in doc['study']:
            doc['study']['uid'] = sha1(time.time(), truncate=truncate)

        return JarvisStudy(doc, root=self.get_root(doc['study']['uid']))

    def find_study_by_uid(self, uid, iid=None):
        """
        Method to find study by raw StudyInstanceUID

        NOTE: if hashed uid is already created, use self.find_study(...) instead

        """
        uid, iid = self.create_ids(uid, iid)

        return self.find_one_study({'study.uid': uid, 'study.iid': iid})

    def find_recent(self, query=None, inactive_for=None):

        return self.find_study(self.recent_query(query, inactive_for))

    def find_one_recent(self, query=None, inactive_for=None):
        """
        Method to find recent study fulfilling query

        """
        return self.find_one_study(self.recent_query(query, inactive_for))

    def recent_query(self, query=None, inactive_for=None):
        """
        Method to add recent criteria to query

        """
        query = query or {}
        t = time.time() - self.jhubd['refresh']['time-recent']
        query['study.status.updated_at'] = {'$gte': t}

        if type(inactive_for) is int:
            query['study.status.updated_at']['$lte'] = time.time() - inactive_for

        return query

    def add_existing_doc_id(self, study):
        """
        Method to add existing document ObjectId to study if matching uid is found

        """
        if study._id is not None: 
            return

        # --- Determine if uid already exists
        uid = study.study.get('uid', None)
        if uid is None:
            return

        doc = self.find_one({'study.uid': uid})
        if doc is not None:
            study._id = doc['_id']

    def upsert_study(self, study, verbose=True):

        self.add_existing_doc_id(study)
        self.upsert(study.to_json(), verbose=verbose)

    def remove(self, docs=[], to_abs_path=True, verbose=True):
        """
        Method to remove documents from db and fnames from disk

        """
        # --- Find fnames
        fnames = []
        for doc in docs:
            if 'arrays' in doc:
                for arr in doc['arrays']:
                    if 'fname' in arr:
                        fs = arr['fname'] if type(arr['fname']) is list else [arr['fname']]
                        if to_abs_path:
                            fs = ['{}/{}'.format(self.configs['store'], f) for f in fs]
                        fnames += fs
            printr('Total of %08i files to remove' % len(fnames))
        
        printd('Total of %08i file(s) to remove' % len(fnames))
        printd('Total of %08i BSON(s) to remove' % len(docs))

        if verbose:
            if input('Are you sure you want to proceed (Y/n)? ') != 'Y':
                return False

        # --- Remove fnames
        for n, fname in enumerate(fnames):
            if os.path.exists(fname):

                dst = '%s/.trash/%s/%s' % (self.configs['store'], fname.split('/')[-2], fname.split('/')[-1])
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.move(src=fname, dst=dst)
                printd('Deleting file: %08i' % (n + 1))

        # --- Remove directories
        dirs = set([os.path.dirname(f) for f in fnames])
        for d in dirs:
            if os.path.exists(d):

                shutil.rmtree(d)
                printd('Deleting dirs: %08i' % (n + 1))

        # --- Remove documents
        for n, doc in enumerate(docs):
            if '_id' in doc:

                self.collection.delete_one({'_id': doc['_id']})
                printd('Deleting BSON: %08i' % (n + 1))

        return True

    def remove_empty_dirs(self):
        """
        Method to remove empty directories in the store folder

        """
        dirs = glob.glob('%s/*/' % self.configs['store'])
        empty = []

        for d in dirs:
            if not os.listdir(d):
                printd('Empty directory found: %s' % d)
                empty.append(d)

        if len(empty) == 0:
            printd('No empty directories found.')
            return

        if input('Are you sure you want to remove %i empty directories (y/n)? ' % len(empty)) != 'y':
            return

        trash_bin = '%s/.trash/empty_dirs' % self.configs['store'] 
        os.makedirs(trash_bin, exist_ok=True)

        for c, d in enumerate(empty):
            printd('Moving to trash %06i/%06i: %s' % (c + 1, len(empty), os.path.dirname(d)), end='\r')
            shutil.move(src=d, dst=trash_bin)

    def remove_studies(self, studies=[], verbose=True):

        docs = [study.to_json(to_rel_path=False) for study in studies]
        self.remove(docs, to_abs_path=False, verbose=verbose)

    def create_ids(self, uid, iid=None, truncate=10):
        """
        Method to return UID hash and IID

        """
        iid = iid or self.ENV['HUB_INSTITUTION_ID']
        
        return sha1(uid + iid, truncate=truncate), iid

    def export_studies(self, query, dst_dir='./export', symlink=True, **kwargs):
        """
        Method to export studies

        """
        for study in self.find_study(query):
            study.copy_files(
                dst_dir='{}/{}'.format(dst_dir, study.study['uid']),
                symlink=symlink, **kwargs)

    def export_studies_by_uids(self, uids, dst_dir='./export', symlink=True, **kwargs):
        """
        Method to export studies based on list of uids

        """
        for uid in uids:
            self.export_studies(query={'study.uid': uid}, dst_dir=dst_dir, symlink=symlink, **kwargs)
