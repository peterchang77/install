import os, shutil, glob, pymongo, time, getpass
from jarvis.utils.general import *

class MongoClient(Base):

    def __init__(self, host=None, port=None, username=None, password=None, authSource='admin', authMechanism='SCRAM-SHA-256', verbose=True, **kwargs):

        self.configs = {}
        self.init_custom(**kwargs)
        self.init_client(host, port, username, password, authSource, authMechanism)
        self.verbose = verbose 

    def init_custom(self, **kwargs): pass

    def init_server(self, host, port):

        return {}

    def auto_reconnect(func):

        def wrapper(self, *args, **kwargs):

            MAX_RECONNECT_ATTEMPTS = 5 

            for attempt in range(MAX_RECONNECT_ATTEMPTS):
                try: 
                    return func(self, *args, **kwargs)
                except pymongo.errors.AutoReconnect as e:
                    time.sleep(2 ** (attempt + 1))

        return wrapper

    @auto_reconnect
    def init_client(self, host, port, username, password, authSource='admin', authMechanism='SCRAM-SHA-256'):

        username = username or self.ENV.get('USER', None) or getpass.getuser()
        password = password or self.ENV.get('SECRET', None) or getpass.getpass()

        # --- Initialize server parameters
        server = self.init_server(host, port)
        server.update({
            'username': username,
            'authSource': authSource,
            'authMechanism': authMechanism})
        server['port'] = int(server['port'])

        # --- Initialize connection
        self.client = pymongo.MongoClient(password=password, **server)

        # --- Initialize self.configs 
        self.configs.update(server)

        # --- Initialize db, collection
        self.db = None
        self.collection = None

    @auto_reconnect
    def add_user(self, username, password, roles):
        """
        Method to add user

        NOTE: ensure that current client user is admin

        :params

          (str)  username
          (str)  password
          (list) roles     : [{'role': '...', 'db': '...'}, ...]

        """
        cmd = 'updateUser' if username in self.get_users(abbreviated=True) else 'createUser'
        self.client.admin.command(cmd, username, pwd=password, roles=roles)

    @auto_reconnect
    def get_users(self, abbreviated=False):

        users = self.client.admin.command('usersInfo')['users']

        if abbreviated:
            users = [u['user'] for u in users]

        return users

    @auto_reconnect
    def drop_user(self, username):

        if input('Drop user: {} (Y/n)? '.format(username)) == 'Y':
            self.client.admin.command('dropUser', username)

    @auto_reconnect
    def use(self, db, collection, create_index=False, verbose=True):
        """
        Method to select provided db and collection

        """
        self.db = self.client[db]
        self.collection = self.db[collection]

        # --- Create indices 
        if create_index and collection not in self.db.list_collection_names():
            self.collection.create_index('study.uid', unique=True)
            self.collection.create_index('study.sid')
            self.collection.create_index('study.pid')
            self.collection.create_index('study.iid')

        self.configs['db'] = db
        self.configs['collection'] = collection 

        if self.verbose and verbose:
            self.count()

    @auto_reconnect
    def pwd(self):
        """
        Method to print currently selected db and collection

        """
        printd('Using db = {} | collection = {}'.format(
            self.configs['db'],
            self.configs['collection']))

    @auto_reconnect
    def count(self):

        if self.collection is not None:
            self.pwd()
            printd('A total of {} document(s) present'.format(self.collection.count_documents({})))

    @auto_reconnect
    def find(self, query=None, **kwargs):

        if self.collection is not None:
            return self.collection.find(query or {}, *kwargs)

    @auto_reconnect
    def find_one(self, query=None):

        if self.collection is not None:
            return self.collection.find_one(query or {})

    @auto_reconnect
    def upsert(self, doc, verbose=True):
        """
        Method to either replace doc in database; if None exists, insert. 

        """
        if '_id' in doc:

            if self.verbose and verbose:
                if input('Are you sure you want to replace doc (y/n)? ') != 'y':
                    return

            self.collection.replace_one({'_id': doc['_id']}, doc)

        else:
            self.collection.insert_one(doc)

    @auto_reconnect
    def delete_one(self, doc):

        if self.collection is not None:
            self.collection.delete_one({'_id': doc['_id']})

    @auto_reconnect
    def find_and_modify(self, **kwargs):

        if self.collection is not None:
            return self.collection.find_and_modify(**kwargs)
