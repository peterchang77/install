import os, json, random, socket, time
from .client import MongoClient
from jarvis.utils.general import printr, printd, sha1

def join(cluster, name=None, port=None, N=1, db='cluster-main', collection='nodes', sleep=2, verbose=True, **kwargs):
    """
    Method to join current node to cluster and await total of N nodes to join

    :params

      (str) cluster         : name of cluster to join
      (str) name            : hostname or IP address of current worker 
      (int) port            : port to associate with current worker; if None then random open port is allocated
      (int) N               : required total number of workers before cluster is initialized
      (str) db              : name of MongoDB database to store cluster information
      (str) collection      : name of MongoDB collection to store cluster information

    """
    doc = {}

    # --- Create Mongo client
    client = init_client(db=db, collection=collection, **kwargs)

    with Port() as p:

        # --- Allocate random port
        port = port or p.bind_random()
        name = name or socket.gethostbyname(socket.gethostname())

        worker = {'name': name, 'port': port} 

        try:

            # --- Add current worker
            doc = client.find_and_modify(
                query={
                    'cluster': cluster,
                    'counter': N},
                update={'$addToSet': {'workers': worker}},
                new=True,
                upsert=True)

            # --- Wait for all N workers to join
            while len(doc['workers']) < N:

                time.sleep(sleep)
                doc = client.find_one(query={'cluster': cluster})
                printr('PENDING: total of {}/{} workers joined'.format(len(doc['workers']), N), verbose=verbose)

            printr('COMPLETE: total of {}/{} workers joined'.format(len(doc['workers']), N), verbose=verbose)

            # --- Decrement counter
            doc = client.find_and_modify(
                query={'cluster': cluster},
                update={'$inc': {'counter': -1}},
                new=True)

            # --- Clean up
            if doc['counter'] == 0:
                client.delete_one(doc)

            doc.pop('counter')

            # --- Attach current worker
            doc['current'] = worker 

        except:

            doc = client.find_one({'cluster': cluster})
            if doc is not None:
                client.delete_one(doc)

        finally: pass

    return doc

def reset(db='cluster-main', collection='nodes', **kwargs):
    """
    Method to reset MongoDB database / collection

    """
    if input('Clear db = {} | collection = {} (Y/n)? '.format(db, collection)) == 'Y':

        # --- Create Mongo client
        client = init_client(db=db, collection=collection, **kwargs)
        client.db.drop_collection(collection)

def init_client(host=None, port=None, db='cluster-main', collection='nodes', verbose=False, **kwargs):

    host = host or os.environ.get('JARVIS_CLUSTER_MONGO_HOST', '127.0.0.1')
    port = port or os.environ.get('JARIVS_CLUSTER_MONGO_PORT', 7700)

    # --- Create Mongo client
    client = MongoClient(host=host, port=port, **{**kwargs, **{'username': 'worker', 'password': 'worker'}})
    client.use(db, collection, verbose=verbose)

    return client

def join_tf(strategy='MultiWorkerMirroredStrategy', chief=None, **kwargs):
    """
    Method to join nodes and set TF_CONFIG environment variable

    See nodes.join(...) for further information

    """
    # --- Join nodes
    doc = join(**kwargs)

    assert 'current' in doc, 'ERROR could not join node to cluster'

    # --- Create workers
    workers = sorted(['{name}:{port}'.format(**w) for w in doc['workers']])

    if chief in workers:
        workers.pop(workers.index(chief))
        workers = [chief] + workers

    current = '{name}:{port}'.format(**doc['current'])

    # --- Set TF_CONFIG
    os.environ['TF_CONFIG'] = json.dumps({
        'cluster': {'worker': workers},
        'task': {
            'type': 'worker', 
            'index': workers.index(current)}})

    return doc 

class Port():

    def __init__(self):

        self.socket = None

    def __enter__(self):

        return self

    def bind_random(self):

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(('', 0))

        return self.socket.getsockname()[1]

    def __exit__(self, exc_type, exc_value, traceback):

        if self.socket is not None:
            self.socket.close()
