import multiprocessing as mp
import pydicom
from jarvis.utils.general import printp, recursive_set, recursive_set_with_keys

def read_header(fname, pattern=['StudyInstanceUID', 'SeriesInstanceUID']):
    """
    Method to read header for single file

    """
    try:
        ds = pydicom.read_file(fname, stop_before_pixels=True)
        headers = {h: getattr(ds, h, None) for h in pattern}
    except: 
        headers = {k: None for k in pattern}

    return headers

def read_headers(fnames, pattern=['StudyInstanceUID', 'SeriesInstanceUID'], verbose=False):
    """
    Method to parse raw (flat) list of DICOM paths

    """
    parsed = {}

    for n, fname in enumerate(fnames):

        printp('Parsing DICOM objects', (n + 1) / len(fnames), verbose=verbose)

        headers = read_header(fname, pattern)
        recursive_set_with_keys(parsed, list(headers.values()), [fname])

    return parsed

def read_headers_mp(fnames, pattern=['StudyInstanceUID', 'SeriesInstanceUID'], processes=4, chunks=100):

    pool = mp.Pool(processes=4)
    parsed = {}

    for i in range(round(len(fnames) / (chunks * processes) + 0.5)):

        ss = [i * chunks * processes + p * chunks for p in range(processes)]
        fs = [fnames[s:s+chunks] for s in ss]
        rs = [pool.apply_async(read_headers, args=([f, pattern])) for f in fs]

        for r in rs:
            recursive_set(d0=parsed, d1=r.get())

    pool.close()
        
    return parsed 

def read_modality(fnames, verbose=False):
    """
    Method to determine modality of provided list of fnames

    """
    for n, fname in enumerate(fnames):

        printp('Parsing DICOM objects', (n + 1) / len(fnames), verbose=verbose)
        ds = pydicom.read_file(fname, stop_before_pixels=True)
        modality = getattr(ds, 'Modality', None)

        if modality is not None:
            return str(modality).upper()
