import os, time
from .client import HubClient 
from jarvis.utils.general import printd, Base

class HubDaemon(Base):

    def __init__(self, verbose=True):

        # --- Initialize
        self.load_configs()
        self.init_custom()

        # --- Initialize clients 
        self.init_clients()

        printd('STARTING | {} (HubDaemon)'.format(self.name), verbose=verbose)

    def init_clients(self):
        
        # --- Initialize clients
        src = self.configs['db']['src']
        dst = self.configs['db']['dst']

        self.src = HubClient()
        self.src.use(db=src['name'], collection=src['collection'], verbose=False)

        if src == dst:
            self.dst = self.src
        else:
            self.dst = HubClient()
            self.dst.use(db=dst['name'], collection=dst['collection'], verbose=False)

        # --- Create listener paths if needed
        if self.configs['path'] is not None:
            os.makedirs(self.configs['path'], exist_ok=True)

    def init_custom(self): pass

    def exec_actions(self): pass

    def find_recent(self, query=None, client=None, inactive_for=False):

        client = client or self.src
        inactive_for = self.configs['time'] if inactive_for else None

        return client.find_recent(query, inactive_for=inactive_for)

    def upsert_study(self, study, client=None, **kwargs):

        client = client or self.dst
        return client.upsert_study(study, **kwargs)

    def start(self, single_iteration=False):

        while True:

            self.exec_actions()

            if single_iteration:
                break

            time.sleep(self.jhubd['refresh']['time-sleep'])
