import os, glob, shutil, copy, json, time
from jarvis.utils.general import sha1, recursive_set, printd
from jarvis.utils import io, arrays as jars
from jarvis_dicom import load_multiseries, read_headers, convert_to_snake_case
from jarvis_pacs import Anonymizer

class JarvisStudy():

    def __init__(self, doc=None, path=None, root='', load=None, save=None, **kwargs):

        # --- Init paramaters 
        self.load = load
        self.save = save
        self.root = root

        self.anonymizer = None
        self.cached = {}

        # --- Init trash bin
        self.trash = '{}/.trash'.format('/'.join(self.root.split('/')[:-2]))

        # --- Expand to absolute paths
        if root != '' and doc is not None:
            doc = self.to_abs_path(doc=doc) 

        # --- Initialize doc
        self.init_attrib(doc, **kwargs)

        # --- Import 
        if path is not None:
            self.run_import(pattern=path, **kwargs)

    def new(self, doc=None, load=None, save=None, **kwargs):

        doc = doc or self.to_json()
        load = load or self.load
        save = save or self.save

        return Study(doc=doc, load=load, save=save, **kwargs)

    def refresh_status(self, unlock=True):
        
        self.study['status'] = {**self.study['status'], 
            **{'updated_at': time.time(), 'recent': True}}

        if unlock:
            self.study['status']['locked'] = False

    def init_attrib(self, doc, **kwargs):

        doc = doc or {}

        # --- Stratify dicts by _hash-*
        for n, h in zip(
            ['arrays', 'series', 'coords', 'fviews'],
            ['unique', 'series', 'coords', 'fviews']):

            h = '_hash-{}'.format(h)

            dicts = kwargs.get(n, None) or doc.get(n, None) or []

            setattr(self, n, {d[h]: d for d in dicts if h in d})

        # --- Set study
        self.study = kwargs.get('study', None) or doc.get('study', {})

        if 'uid' not in self.study:
            self.study['uid'] = ''

        if 'status' not in self.study:
            self.study['status'] = {}

        # --- Set _id
        self._id = doc.get('_id', None)

        # --- Set loaded arrays
        self.loaded = {}

    def remap_headers(self, d):
        """
        Method to remap current headers to new values (based on provided dict)

        :params

          (dict) d : new mappings = {

            'pid': {
                old_value_00: new_value_00,
                old_value_01: new_value_01, ...}, 
            'sid': ...,
            'study_uid': ..., 
            'series_uid': ...,

          }

        """
        remap = lambda obj, d : {k: d[k].get(v, None) if k in d else v for k, v in obj.items()}

        # --- Remap study.study
        self.study = remap(self.study, d) 

        # --- Remap in study['header']
        self.study['header'] = remap(self.study['header'], d) 

        # --- Remap in series['header']
        for series in self.series.values():
            series['header'] = remap(series['header'], d) 

    # ===================================================================================
    # ARRAYS MANIPULATION
    # ===================================================================================

    def add_array(self, arr=None, fname=None, hash_series=None, **kwargs):
        """
        Method to add JarvisArray to current study object

        """
        arrs = {}

        if hash_series is not None and type(fname) is list:

            # --- Find all existing files in series
            s = self.find_arrays(hash_series=hash_series)
            e = [f for unique in s for f in self.arrays[unique]['fname']] 

            e = {k: v[0] for k, v in read_headers(e, pattern=['SOPInstanceUID']).items()}
            f = {k: v[0] for k, v in read_headers(fname, pattern=['SOPInstanceUID']).items()}

            n = [v for k, v in f.items() if k in e]

            # --- No new files
            if len(n) == len(f):
                self.study['import-trash'] += fname
                return arrs 

            if len(n) > 0:
                self.study['import-trash'] += n

            for unique in s:
                self.del_array(hash_unique=unique)

            fname = {**f, **e}
            fname = list(fname.values())

        # --- Add arrays (multiple DICOMs)
        if  (type(fname) is list) or \
            (type(fname) is str and fname[-1] == '/') or \
            (type(fname) is str and fname[-4] == '.dcm'):

            series = load_multiseries(fname, **kwargs)

            for v in series.values():

                arr = jars.create(**v)
                arrs.update(self.add_array_single(arr, fname=v['meta']['fnames-orig']))

            return arrs

        # --- Add array (single)
        arr = arr or self.load_array(fname=fname, **kwargs)
        arrs = self.add_array_single(arr, fname=fname)

        return arrs

    def add_array_single(self, arr, fname):

        u = arr.to_json()

        # --- (1) If hash_unique already exists, ignore
        if u['arrays']['_hash-unique'] in self.arrays:
            printd('Repeated: {}'.format(u['arrays']['_hash-unique']))
            self.study['import-trash'].extend(fname) if type(fname) is list else self.study['import-trash'].append(fname)
            return {}

        u['arrays']['fname'] = fname 

        for n, h in zip(
            ['arrays', 'series', 'coords', 'fviews'],
            ['unique', 'series', 'coords', 'fviews']):

            h = '_hash-{}'.format(h)

            if u[n][h] not in getattr(self, n):
                getattr(self, n)[u[n][h]] = u[n]

        # --- Update study
        recursive_set(self.study, u['study'])

        return {u['arrays']['_hash-unique']: arr}

    def del_array(self, arr=None, hash_unique=None, **kwargs):

        hash_unique = hash_unique or arr.attrib._hash_unique

        if hash_unique not in self.arrays:
            return

        arrays_dict = self.arrays.pop(hash_unique)

        for k in ['series', 'coords', 'fviews']:
            h = '_hash-{}'.format(k)
            if h in arrays_dict:
                value = arrays_dict[h] 
                kwargs = {h[1:]: value}
                matches = self.find_arrays(**kwargs)
                if len(matches) == 0:
                    getattr(self, k).pop(value)

    def load_array(self, hash_unique=None, fname=None, load=None, refresh=False, **kwargs):
        """
        Method to load fname as JarvisArray 

        """
        if (hash_unique in self.cached) and not refresh:
            return self.cached[hash_unique]

        if fname is None:
            printd('ERROR hash_unique does not match cached volume and fname is None')
            return

        load = load or self.load or io.load

        ret = load(fname, **kwargs)

        if type(ret) is tuple:
            data, meta = ret
        else:
            data = ret
            meta = None

        arr = jars.create(fname) if data is None else jars.create(data=data, meta=meta)
        self.cached[arr.attrib._hash_unique] = arr

        return arr

    def save_array(self, hash_unique=None, arr=None, fname=None, **kwargs):
        """
        Method to save JarvisArray

        """
        save = save or self.save

        arr = arr or self.load_array(hash_unique=hash_unique, **kwargs)

        # --- Save as Jarvis object
        if save is None:
            arr.to_hdf5(fname) if hasattr(arr, 'to_hdf5') else arr.to_json(fname)

        # --- Save as custom object
        else:
            save(fname, arr.data, **kwargs)

    def get_all_files(self):

        files = []

        for v in self.arrays.values():
            if type(v['fname']) is list:
                files += v['fname']
            elif type(v['fname']) is str:
                files.append(v['fname'])

        return files 

    # ===================================================================================
    # STUDY-LEVEL MANIPULATION 
    # ===================================================================================

    def find(self, **kwargs): pass

    def find_orientation(self, orient='AXI'): pass

    def find_slices(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_mu(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_sd(self, greater_than=None, less_than=None, maximum=False, minimum=False): pass

    def find_modality(self): pass

    def find_contrast(self): pass

    def find_arrays(self, **kwargs):

        matched = lambda h, value : set([k for k, v in self.arrays.items() if v.get(h, None) == value])
        matches = set(self.arrays.keys())

        for h, value in kwargs.items():

            h = '_' + h.replace('_', '-')
            matches = matches & matched(h, value)

        return matches

    # ===================================================================================
    # IMPORT 
    # ===================================================================================

    def add_import_matching(self, pattern, recursive=True, verbose=False, **kwargs):
        """
        Method to add files to self.study['import'] based on search pattern 

        """
        fnames = glob.glob(pattern, recursive=recursive)

        if len(fnames) > 0:
            ext = fnames[0].split('.')[-1]

            if ext in ['dcm']:

                d = read_headers(fnames, verbose=verbose)
                assert len(d) == 1, 'ERROR more than one StudyInstanceUID found'
                return self.add_import(next(iter(d.values())))

            else:

                d = {f: f for f in fnames}
                return self.add_import(d)

    def add_import(self, d):
        """
        Method to recursively add files into self.study['import']
        
        :return

          (bool) status : True if updated, else False

        """
        if 'import' not in self.study:
            self.study['import'] = {}

        # --- Determine number total files
        count = lambda : sum([len(v) for v in self.study['import'].values()])
        n = count()

        # --- Update
        d = {sha1(str(k), truncate=10): v for k, v in d.items()}
        recursive_set(self.study['import'], d)

        # --- Remove redundant elements 
        self.study['import'] = {k: list(set(v)) if type(v) is list else [v] for k, v in self.study['import'].items()}

        return count() > n

    def run_import(self, pattern=None, save_files=False, move_files=False, copy_files=False, load=None, verbose=False, all_headers_raw=False, overwrite_root=False, **kwargs):
        """
        Method to run import based on files in self.study['import']

        """
        if pattern is not None:
            self.add_import_matching(pattern, verbose=verbose, **kwargs)

        if 'import' not in self.study:
            return

        arrays_dicts = []
        self.study['import-trash'] = []

        for hash_series, fname in self.study['import'].items():

            printd('Importing: {} ({})'.format(self.study['uid'] or 'UID unknown', hash_series), verbose=verbose)
            arrs = self.add_array(fname=fname, load=load, hash_series=hash_series, all_headers_raw=all_headers_raw, verbose=verbose)

            for unique, arr in arrs.items():
                arrays_dicts.append(self.arrays[unique])
                if save_files:
                    self.save_files(arrs=[arr], **kwargs)

        if copy_files:
            self.copy_files(arrays_dicts=arrays_dicts, **kwargs)

        if move_files:
            self.move_files(arrays_dicts=arrays_dicts, **kwargs)

        self.study.pop('import')

        # --- Trash
        if move_files:
            for fname in self.study['import-trash']:
                self.move_to_trash(fname)

        self.study.pop('import-trash')

        # --- Root
        self.set_root(overwrite=overwrite_root)

    def set_root(self, overwrite=False):
        """
        Method to infer root location based on common prefix in fnames

        """
        if not overwrite and self.root != '':
            return

        dcms = self.get_all_files()
        for i in range(dcms[0].count('/'), 1, -1):
            r = '/'.join(dcms[0].split('/')[:i])
            if all([r in d for d in dcms]):
                break

        self.root = r 

    # ===================================================================================
    # ANONYMIZATION 
    # ===================================================================================

    def anonymize(self, anon_dir='./anon', orig_dir=None, rules=None, **kwargs):
        """
        Method to anonymize all data in current study

        """
        # --- Ensure that files are present
        dcms = self.get_all_files()
        if len(dcms) == 0:
            return

        # --- Infer orig_dir
        orig_dir = orig_dir or self.root
        if orig_dir == '':
            printd('ERROR no orig_dir specified and self.root is empty')
            return

        # --- Initialize
        self.init_anonymizer(rules=rules)

        # --- Anonymize
        configs = {'series': {'status': ['quar', 'burn']}}
        decrypt = self.anonymizer.clean(orig_dir=orig_dir, anon_dir=anon_dir, configs=configs, **kwargs)
        series = self._add_unique_to_decrypt(decrypt['series'])

        # --- Process "quar" series (remove array) 
        for hash_unique in series[series.quar]['hash-unique']:
            self.del_array(hash_unique=hash_unique)
            self.cached.pop(hash_unique, None)

        # --- Process "burn" series (reload)
        for hash_unique in series[series.burn]['hash-unique']:
            pass

        # --- Create remapping to newly anonymized headers
        self.remap_headers(self._find_headers_remapping(series))

        # --- Remove _raw headers
        for h in self.series:
            if 'header' in self.series[h]:
                self.series[h]['header'].pop('_raw', None)

        # --- Update root
        self.to_new_root(root=anon_dir)
        self._id = None

        return decrypt

    def init_anonymizer(self, rules=None):
        """
        Method to initialize anonymizer

        """
        # --- Create anonymizer if needed
        if self.anonymizer is None:
            self.anonymizer = Anonymizer()
            self.init_anonymizer_headers()

        # --- Load rules
        self.anonymizer.load_rules(**(rules or {}))

    def init_anonymizer_headers(self):
        """
        Method to prepare anonymizer headers

        """
        self.ANON_HEADERS = {}

        # --- Define fields (anons.yml + Jarvis arrays)
        self.ANON_HEADERS['fields']

        # --- Define status (anons.yml + ['quar', 'burn'])
        self.ANON_HEADERS['status']

        pass

    def _add_unique_to_decrypt(self, decrypt, **kwargs):
        """
        Method to reassociate hash_unique to each series (row) in decrypt

        """
        key_camel = self.anonymizer.anons['decrypt']['unique']
        key_snake = convert_to_snake_case(key_camel)

        # --- Create dict mapping unique_key to hash_unique
        series = {s['header'][key_snake]:
            self.find_arrays(**{'hash-series': h}).pop() for h, s in self.series.items()}

        # --- Add hash_unique to decrypt table
        decrypt['hash-unique'] = [series[k] for k in decrypt[key_camel]] 

        return decrypt

    def _find_headers_remapping(self, decrypt, new_sid_key='StudyInstanceUID-anon'):
        """
        Method to find headers to remap based on decryption key

        """
        # --- Create mapping from old to new sid
        sid = str(decrypt[new_sid_key].iloc[0])
        d = {'sid': {self.study['sid']: sha1(sid, truncate=10)}}

        # --- Create mapping from remaining anonymized fields in decrypt
        for h in self.ANON_HEADERS['fields']:
            d[convert_to_snake_case(h)] = {o: a for 
                o, a in zip(decrypt[h + '-orig'], decrypt[h + '-anon'])}

        return d

    # ===================================================================================
    # FILE MANIPULATION 
    # ===================================================================================

    def copy_files(self, dst_dir=None, arrays_dicts=None, symlink=False, hash_unique=True, **kwargs):
        """
        Method to copy (or symlink) files to new dst

        """
        func = os.link if symlink else shutil.copy
        self._copy_or_move_files(func, dst_dir, arrays_dicts, hash_unique, **kwargs)

    def move_files(self, dst_dir=None, arrays_dicts=None, hash_unique=True, **kwargs):
        """
        Method to move files to new dst

        """
        self._copy_or_move_files(shutil.move, dst_dir, arrays_dicts, hash_unique, **kwargs)

    def save_files(self, dst_dir=None, arrays_dicts=None, arrs=None, **kwargs):
        """
        Method to save files 

        By default, self.root is the dst_dir (unless manually specified)

        """
        # --- Find arrs to save 
        arrs = arrs or arrays_dicts or list(self.arrays.values())
        if type(arrs) is not list:
            arrs = [arrs]

        # --- Create dst_dir
        dst_dir = dst_dir or self.root or './'
        if dst_dir[-1] != '/':
            dst_dir = dst_dir + '/'

        for arr in arrs:

            if type(arr) is dict:
                arr = self.load_array(fname=arr['fname'], **kwargs)

            unique = arr.attrib._hash_unique
            fname = '{}{}.hdf5'.format(dst_dir, unique) if hasattr('to_hdf5', arr) else '{}{}.json'.format(dst_dir, unique)
            self.save_array(arr=arr, fname=fname)

            # --- Update new fname
            self.arrays[unique]['fname'] = fname 

    def _copy_or_move_files(self, func, dst_dir, arrays_dicts=None, hash_unique=True, **kwargs):
        """
        Method to copy or move files

        """
        # --- Find arrays_dicts to move
        arrays_dicts = arrays_dicts or list(self.arrays.values())
        if type(arrays_dicts) is not list:
            arrays_dicts = [arrays_dicts]

        for arrays_dict in arrays_dicts: 

            src = arrays_dict['fname']
            dst = None

            if type(src) is str:
                dst, index = self._copy_or_move_files_single(src, func, dst_dir, arrays_dict, hash_unique, **kwargs)
                
            elif type(src) is list:

                dst = []
                pnd = []

                # --- Identify files already in dst_dir
                for s in src:
                    base, ext = self._create_dst_base_ext(s, dst_dir, arrays_dict, hash_unique)
                    dst.append(s) if s[:len(base)] == base else pnd.append(s)

                # --- Move pending files
                index = self._find_next_index(base, ext)
                for s in pnd:
                    d, index = self._copy_or_move_files_single(s, func, dst_dir, arrays_dict, hash_unique, index, **kwargs)
                    dst.append(d)

            # --- Update new fname
            self.arrays[arrays_dict['_hash-unique']]['fname'] = dst

    def _copy_or_move_files_single(self, src, func, dst_dir, arrays_dict, hash_unique, index=None, overwrite=False):

        if not os.path.exists(src):
            return 

        # --- Create dst components
        dst_base, ext = self._create_dst_base_ext(src, dst_dir, arrays_dict, hash_unique)
        ind = '-{:05d}'.format(index) if type(index) is int else ''

        # --- Create dst
        dst = '{}{}{}'.format(dst_base, ind, ext)

        # --- Overwrite
        if os.path.exists(dst) and not overwrite:
            index = index + 1 if type(index) is int else self._find_next_index(dst_base, ext)
            return self._copy_or_move_files_single(src, func, dst_dir, arrays_dict, hash_unique, index)

        os.makedirs(os.path.dirname(dst), exist_ok=True)
        func(src=src, dst=dst)

        return os.path.abspath(dst), index

    def _create_dst_base_ext(self, src, dst_dir, arrays_dict, hash_unique):

        uniq =  arrays_dict['_hash-unique'] if hash_unique else None
        base, ext = os.path.splitext(os.path.basename(src))
        base = uniq or base

        dst_dir = dst_dir or self.root or './'
        if dst_dir[-1] != '/':
            dst_dir = dst_dir + '/'

        return '{}{}'.format(dst_dir, base), ext

    def _find_next_index(self, base, ext):

        fnames = sorted(glob.glob('{}*{}'.format(base, ext)))

        if len(fnames) > 0:
            index = fnames[-1][:-len(ext)].split('-')[-1] 
            if index.isdigit():
                return int(index) + 1

        return 0 

    def move_to_trash(self, src):

        os.makedirs(self.trash, exist_ok=True)
        dst = '{}/{}'.format(self.trash, os.path.basename(src))
        shutil.move(src=src, dst=dst)

    def to_abs_path(self, fname=None, doc=None):

        if doc is not None:
            if 'arrays' in doc:
                for i in range(len(doc['arrays'])):
                    doc['arrays'][i]['fname'] = self.to_abs_path(doc['arrays'][i]['fname']) 
            return doc

        fname = fname or ''

        if type(fname) is str:
            return '{}{}'.format(self.root, fname)

        if type(fname) is list:
            return [self.to_abs_path(f) for f in fname]

    def to_rel_path(self, fname=None, doc=None):

        if doc is not None:
            if 'arrays' in doc:
                for i in range(len(doc['arrays'])):
                    doc['arrays'][i]['fname'] = self.to_rel_path(doc['arrays'][i]['fname']) 
            return doc

        fname = fname or ''

        if type(fname) is str:
            return fname.replace(self.root, '', 1)

        if type(fname) is list:
            return [self.to_rel_path(f) for f in fname]

    def to_new_root(self, root):
        """
        Method to convert document contents to new root

        """
        # --- To relative paths (del old root)
        doc = {'arrays': list(self.arrays.values())}
        doc = self.to_rel_path(doc=doc)

        # --- To absolute paths (add new root)
        self.root = os.path.abspath(root)
        doc = self.to_abs_path(doc=doc)

        # --- Add to self.arrays
        self.arrays = {d['_hash-unique']: d for d in doc['arrays']} 

    def to_json(self, fname=None, to_rel_path=True):

        self.refresh_status()

        # --- Create doc
        doc = {}
        if self._id is not None:
            doc['_id'] = self._id
        doc['study'] = self.study
        for k in ['arrays', 'series', 'coords', 'fviews']:
            doc[k] = copy.deepcopy(list(getattr(self, k).values()))

        # --- Relative fnames
        if to_rel_path:
            doc = self.to_rel_path(doc=doc)

        # --- Serialize
        if fname is not None:
            os.makedirs(os.path.dirname(fname), exist_ok=True)
            json.dump(unique_dict, open(fname, 'w'))

        return doc
