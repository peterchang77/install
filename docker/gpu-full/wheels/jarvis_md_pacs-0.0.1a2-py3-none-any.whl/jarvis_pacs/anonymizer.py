import os, glob, shutil, yaml, pkg_resources
import pandas as pd
import pydicom
from pydicom.tag import Tag
from jarvis.utils.general import sha1, printd, printp, Base

class Anonymizer(Base):

    def __init__(self, orig_dir=None, quar_dir=None, anon_dir=None, quar='quar-default', meta='meta-default', burn='burn-default', **kwargs):
        """
        Method to initialize Anonymizer object

        """
        # --- Load configs
        self.load_configs(names=['anons'])

        # --- Save folders
        self.code_dir = pkg_resources.resource_filename('jarvis_pacs', '')
        self.orig_dir = orig_dir or self.anons['paths']['orig']
        self.quar_dir = quar_dir or self.anons['paths']['quar']
        self.anon_dir = anon_dir or self.anons['paths']['anon']

        # --- Init rules
        self.rules_hash = None
        self.load_rules(quar=quar, meta=meta, burn=burn)

    def printd(self, msg, ds, verbose, ljust=80):
        """
        Method to print standard message with SOPInstanceUID prefix

        """
        uid = getattr(ds, 'SOPInstanceUID', 'None').ljust(ljust)
        printd('SOPInstanceUID = {} | {}'.format(uid, msg), verbose=verbose)

    def load_rules(self, **kwargs):

        # --- Check rules_hash
        r = sha1({k: kwargs.get(k, '{}-default'.format(k)) for k in ['quar', 'meta', 'burn']}, 16)
        if self.rules_hash is not None:
            if self.rules_hash == r:
                return

        self.rules_hash = r
        self.rules = {}

        for k in ['quar', 'meta', 'burn']:

            self.rules[k] = self.load_yml(
                '{}/rules/{}.yml'.format(self.code_dir, kwargs[k])) 

        # --- Load meta *.csv file
        self.init_meta(kwargs['meta'])

    def load_yml(self, fname):

        assert os.path.exists(fname)

        return yaml.load(open(fname, 'r'), Loader=yaml.FullLoader)

    def load_secret(self):
        """
        Method to load secret phrase

        """ 
        fname = '{}/rules/secret'.format(self.code_dir)
        self.SECRET = open(fname, 'r').readline()

    def init_meta(self, meta):
        """
        Method to initialize dictionary of self.clean_meta rules

        """
        self.rules['meta']['clean'] = pd.read_csv('{}/rules/{}.csv'.format(self.code_dir, meta))

        self.load_secret()
        salt = lambda x : str(x) + self.SECRET 

        # --- Lambdas
        f = {}
        f['hashpid'] = lambda x : sha1(salt(x), truncate=self.anons['hash-truncate'])
        f['hashuid'] = lambda x : self.ENV['PACS_ORG_ROOT'] + str(int(sha1(salt(x)), 16))
        f['remove'] = lambda x : ''

        self.clean_meta = {}
        for n, row in self.rules['meta']['clean'].iterrows():
            if row['method'] in f:
                self.clean_meta[row['name']] = f[row['method']]

        # --- Patient age rule
        to_int = lambda x : int(''.join(filter(str.isdigit, str(x))) or '0')
        to_alp = lambda x : ''.join(filter(str.isalpha, str(x)))
        self.clean_meta['PatientAge'] = lambda x : str(min(max(to_int(x), 
            self.rules['meta']['age-min']),
            self.rules['meta']['age-max'])) + to_alp(str(x))

    def init_directories(self, **kwargs):

        ds = []
        for key in ['orig_dir', 'quar_dir', 'anon_dir']:
            ds.append(kwargs[key] or getattr(self, key))

        assert ds[0] is not None, 'ERROR orig_dir cannot be None'
        assert ds[2] is not None, 'ERROR anon_dir cannot be None'

        return tuple(ds)

    def clean(self, orig_dir=None, quar_dir=None, anon_dir=None, dcms=None, fields=None, unique_key=None, decrypt_csv=None, skip_existing=True, verbose=False):
        """
        Method to anonymize all DICOM files in orig_dir

        """
        orig_dir, quar_dir, anon_dir = self.init_directories(
            orig_dir=orig_dir, quar_dir=quar_dir, anon_dir=anon_dir)

        if dcms is None:
            dcms = glob.glob('{}/**/*.dcm'.format(orig_dir), recursive=True)

        # --- Determine fields to provide anonymization key
        fields = fields or self.anons['decrypt']['fields']

        # --- Initialize
        decrypt_csv = decrypt_csv or self.anons['decrypt']['stored']
        unique_key = '{}-orig'.format(unique_key or self.anons['decrypt']['unique'])
        decrypt = None

        for n, dcm in enumerate(dcms):

            printp('Cleaning DICOM objects', (n + 1) / len(dcms), verbose=verbose)
            d = self.clean_ds(dcm, orig_dir, quar_dir, anon_dir, fields, skip_existing, verbose)

            # --- Update decryption keys 
            if decrypt is None and d is not None:
                decrypt = {k: [] for k in d}

            if d is not None:
                if d[unique_key] not in decrypt[unique_key]:
                    for k in decrypt:
                        decrypt[k].append(d[k])

        if decrypt is not None:
            printd('Cleaned {:05d} DICOM objects'.format(n + 1), verbose=verbose, ljust=100)

        # --- Update decryption *.csv file if requested 
        if decrypt_csv is not None:
            self.save_csv(decrypt_csv, decrypt)

        return pd.DataFrame.from_dict(decrypt)

    def clean_ds(self, dcm, orig_dir, quar_dir, anon_dir, fields, skip_existing, verbose):

        # --- Skip existing
        dst = dcm.replace(orig_dir, anon_dir)
        if skip_existing:
            if os.path.exists(dst):
                return

        # --- Read fields
        ds = pydicom.read_file(dcm)

        # --- Check quarantine
        if self.check_quar_ds(ds=ds, verbose=verbose):

            if quar_dir is not None:
                dst = dcm.replace(orig_dir, quar_dir)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy(src=dcm, dst=dst)

            return

        # --- Save pre-anonymization fields 
        pre_fields = self.extract_fields(ds, 
            fields=fields, suffix='-orig')

        # --- Clean meta-ds
        ds = self.clean_meta_ds(ds)

        # --- Clean burn-ds (if needed load pixel data)
        ds = self.clean_burn_ds(ds)

        # --- Serialize
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        ds.save_as(dst)

        # --- Create anons 
        pst_fields = self.extract_fields(ds, 
            fields=fields, suffix='-anon')

        return {**pre_fields, **pst_fields}

    def create_decryption_table(self, dcm, fields=None):

        # --- Determine fields to provide anonymization key
        fields = fields or self.anons['decrypt']['fields']

        # --- Read fields
        ds = pydicom.read_file(dcm, stop_before_pixels=True)

        # --- Save pre-anonymization fields 
        pre_fields = self.extract_fields(ds, 
            fields=fields, suffix='-orig')

        # --- Clean meta-ds
        ds = self.clean_meta_ds(ds)

        # --- Create anons 
        pst_fields = self.extract_fields(ds, 
            fields=fields, suffix='-anon')

        # --- Create decrypt table
        decrypt = {**pre_fields, **pst_fields}
        decrypt = {k: [v] for k, v in decrypt.items()}

        return pd.DataFrame.from_dict(decrypt)

    def check_quar_ds(self, ds=None, dcm=None, verbose=False):
        """
        Method to check quarantine status

        """
        if ds is None and type(dcm) is str:
            ds = pydicom.read_file(dcm)

        modality = getattr(ds, 'Modality', 'default')

        if modality not in self.rules['quar']:
            self.printd('WARNING modality ( {} ) has no quarantine rules, default rules applied'.format(modality.ljust(4)), ds=ds, verbose=verbose)
            modality = 'default'
        
        for rule in self.rules['quar'][modality]:

            status = {
                'no_pixel_array': self.check_no_pixel_array,
                'secondary_capture': self.check_secondary_capture,
                'burned_annotation': self.check_burned_annotation,
                'rgb': self.check_rgb}[rule](ds)

            if status:
                self.printd('Quarantine triggered: {}'.format(rule), ds=ds, verbose=verbose)
                return rule 

        return False

    def clean_meta_ds(self, ds):
        """
        Method to anonymize metadata in entire Pydicom DataSet object

        """
        for attr, func in self.clean_meta.items():
            if hasattr(ds, attr):
                setattr(ds, attr, func(getattr(ds, attr)))

        return ds

    def clean_burn_ds(self, ds):
        """
        Method to anonymize burned in info in entire Pydicom DataSet object

        """
        for rule in self.rules['burn']:
            if self.check_fields_all(ds, rule['fields']):
                ds = self.clean_pixels(ds, rule['coords'])

        return ds

    def clean_pixels(self, ds, coords):

        if not hasattr(ds, 'PixelData'):
            return ds

        # --- Decompress 
        ds.decompress()
        pa = ds.pixel_array

        # --- Allow write 
        pa.setflags(write=1)
        
        # --- Convert to RGB
        if pa.ndim == 3:
            pa = pydicom.pixel_data_handlers.util.convert_color_space(pa, 'YBR_FULL', 'RGB')
            ds.PhotometricInterpretation = 'RGB'

        # --- Remove 
        value = float(getattr(ds, 'RescaleIntercept', 0))
        for coord in coords:
            pa[coord['y0']:coord['y1'], coord['x0']:coord['x1']] = value 
            
        # --- Disallow write 
        pa.setflags(write=0)

        ds.PixelData = pa.tostring()

        return ds

    # ============================================================
    # HEADER CHECKS
    # ============================================================

    def extract_field(self, ds, field, default=None):
        """
        Method to extract field

        :params

          (str) field : attr OR string of tag [xxxx, xxxx]

        """
        return getattr(ds, field, default) if field[0] != '[' else ds.get(self.to_tag(field), default)

    def extract_fields(self, ds, fields=[], suffix=''):

        return {'{}{}'.format(k, suffix): self.extract_field(ds, k) for k in fields}

    def to_tag(self, field):

        return Tag(''.join(filter(str.isdigit, field)))

    def check_fields_all(self, ds, rules):
        """
        Method to check if ALL rules match ds 

        """
        for field, value in rules.items():
            if not self.check_fields_equal(ds, field, value):
                return False

        return True 

    def check_fields_any(self, ds, rules):
        """
        Method to check if ANY rules match ds

        """
        for field, value in rules.items():
            if self.check_fields_equal(ds, field, value):
                return True

        return False 

    def check_fields_equal(self, ds, field, value):
        """
        Method to check if field is equal to value

        """
        if field in ds:
            source = self.extract_field(ds, field)
            return value in str(source) if type(value) is str else value == source
        else:
            return False

    def check_no_pixel_array(self, ds):
        """
        Method to check if DICOM as no pixels

        """
        return not hasattr(ds, 'PixelData')

    def check_secondary_capture(self, ds):
        """
        Method to check if DICOM is a secondary capture

        """
        return self.check_fields_any(ds, rules={
            'SOPClassUID': '1.2.840.10008.5.1.4.1.1.7',
            'MediaStorageSOPClassUID': '1.2.840.10008.5.1.4.1.1.7',
            'ImageType': 'SECONDARY'})

    def check_burned_annotation(self, ds):
        """
        Method to check if DICOM has 'BurnedAnnotation' flag

        """
        return getattr(ds, 'BurnedAnnotation', None) == 'YES' 

    def check_rgb(self, ds):
        """
        Method to check if DICOM is RGB file

        """
        samples = getattr(ds, 'SamplesPerPixel', 1)
        highbit = getattr(ds, 'HighBit', 16)

        return (samples == 3) & (highbit == 8) 
