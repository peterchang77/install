from . import mvk, mzl
import numpy as np

def load_mvk(fname, **kwargs):

    infos = kwargs.get('infos', None) or {'full_res': True}
    data, obj = mvk.load(fname, infos=infos)

    affine = np.eye(4)
    affine[np.arange(3), np.arange(3)] = obj['voxel_size'][1:]

    return data, {'affine': affine} 

def load_mzl(fname, **kwargs):

    data = mzl.decompress(fname, method=kwargs.get('method', 'full'))

    return data, {'affine': np.eye(4)} 
