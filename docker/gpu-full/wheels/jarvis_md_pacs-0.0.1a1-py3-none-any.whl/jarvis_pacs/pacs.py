import os, glob, shutil, pandas as pd
import gdcm
from jarvis.utils.general import Base

# ================================================================== 
# GLOBAL VARIABLES
# ================================================================== 

TAGS = {
    'PatientID': [0x0010, 0x0020],
    'AccessionNumber': [0x0008, 0x0050],
    'StudyDate': [0x0008, 0x0020],
    'StudyDescription': [0x0008, 0x1030],
    'PatientAge': [0x0010, 0x1010],
    'Modality': [0x0008, 0x0060],
    'BodyPartExamined': [0x0018, 0x0015],
    'ReferringPhysicianName': [0x0008, 0x0090],
    'AdditionalPatientHistory': [0x0010, 0x21b0],
    'StudyInstanceUID': [0x0020, 0x000d],
    'SeriesInstanceUID': [0x0020, 0x000e],
    'SOPInstanceUID': [0x0020, 0x0242]}

# --- Template query dictionary
QUERY = {k: '*' for k in TAGS}

# ================================================================== 
# GDCM TAG MANIPULATION 
# ================================================================== 

TAGS_GDCM = lambda key : gdcm.Tag(*TAGS[key])

def set_tag(ds, tag, value):
    """
    Set tag with value and insert into ds

    """
    de = gdcm.DataElement(TAGS_GDCM(tag))
    de.SetByteValue(value, gdcm.VL(len(value)))
    ds.Insert(de)

    return ds

def create_ds(query):

    # --- Create ds
    ds = gdcm.DataSet()
    for tag, value in query.items():
        ds = set_tag(ds=ds, tag=tag, value=value)

    return ds

# ================================================================== 
# DISME OPERATIONS (C-FIND, C-MOVE) 
# ================================================================== 

def perform_find(configs, query={}, results=None):
    """
    Method to perform PACS query

    :params

      (dict) configs : a configuration dictionary for PACS server information 
      (dict) query   : a query dictionary
      (dict) results : if provided, append current query result to existing results

    :return

      (dict) results

    """
    # --- Create query
    query = {**QUERY, **query}

    # --- Create results
    results = results or {k: [] for k in query}

    # --- Create ds
    ds = create_ds(query)

    # --- Configure query object 
    cnf = gdcm.CompositeNetworkFunctions()
    theQuery = cnf.ConstructQuery(gdcm.ePatientRootType, gdcm.eStudy, ds)

    # --- Prepare the variable for output
    ret = gdcm.DataSetArrayType()
    
    # --- Perform query
    cnf.CFind(
        configs['host'], 
        configs['port_called'], 
        theQuery, 
        ret, 
        configs['aet_called'], 
        configs['aet_calling'])

    # --- Save to dictionary 
    for i in range(len(ret)):
        for tag in query:
            value = str(ret[i].GetDataElement(TAGS_GDCM(tag)).GetValue())
            results[tag].append(value)

    return results

def perform_move(configs, query={}, verbose=False):
    """
    Method to perform C-MOVE

    """
    # --- Create ds query
    ds = create_ds(query)

    # --- Configure query object 
    cnf = gdcm.CompositeNetworkFunctions()
    theQuery = cnf.ConstructQuery(gdcm.ePatientRootType, gdcm.eStudy, ds, True)

    # --- Perform move
    cnf.CMove(
        configs['host'], 
        configs['port_called'], 
        theQuery, 
        configs['port_calling'],
        configs['aet_called'], 
        configs['aet_calling'])

# ================================================================== 
# PACSClient 
# ================================================================== 

def find_requests_dirs():
    """
    Method to find directories used for PACS client and daemons

      {JARVIS_PACS_PATH_REQUESTS}/parse
      {JARVIS_PACS_PATH_REQUESTS}/queue
      {JARVIS_PACS_PATH_REQUESTS}/await
      {JARVIS_PACS_PATH_REQUESTS}/comps
      {JARVIS_PACS_PATH_REQUESTS}/dicom

    Note, {JARVIS_PACS_PATH_REQUESTS} is commonly {JARVIS_HUB_STORE}/reqs

    """
    dirs = ['parse', 'queue', 'await', 'comps', 'dicom']
    reqs = os.environ.get('JARVIS_PACS_PATH_REQUESTS', '')

    requests = {d: '{}/{}'.format(reqs, d) for d in dirs}

    # --- Find default request.yml file
    requests['default-yml'] = '{}/ymls/request.yml'.format(os.path.dirname(__file__))

    return requests

class PACSClient(Base):

    def __init__(self):

        # --- Initialize
        self.load_configs(names=['pacsd'])
        self.init_directories()

        # --- Create server configs
        keys = [
            'PACS_HOST', 
            'PACS_PORT_CALLED', 
            'PACS_PORT_CALLING', 
            'PACS_AET_CALLED', 
            'PACS_AET_CALLING']

        self.server = {k[5:].lower(): self.ENV[k] for k in keys}
        self.server['port_called'] = int(self.server['port_called'])
        self.server['port_calling'] = int(self.server['port_calling'])

    def init_directories(self):
        """
        Method to find and initialize directories

        """
        os.makedirs(self.ENV['PACS_PATH_DOWNLOAD'], exist_ok=True)

        self.requests = find_requests_dirs() 
        for k, d in self.requests.items():
            if k in ['parse', 'queue', 'await', 'comps', 'dicom']:
                os.makedirs(d, exist_ok=True)

    def submit_job(self, name, query=None, csv_file=None, yml_file=None):
        """
        Method to manually submit C-MOVE job to download/reqs/pend

        """
        csv = '{}/{}.csv'.format(self.requests['parse'], name)
        yml = '{}/{}.yml'.format(self.requests['parse'], name)

        # --- Copy *.csv file
        if csv_file is not None:
            shutil.copy(src=csv_file, dst=csv)

        else:
            query = pd.DataFrame.from_dict(query)
            query.to_csv(csv, index=False)

        # --- Copy *.yml file
        yml_file = yml_file or self.requests['default-yml'] 
        shutil.copy(src=yml_file, dst=yml)

    def load_df(self, query=None, csv_file=None):

        if type(query) is pd.DataFrame:
            return query

        assert query or csv_file is not None

        if csv_file is not None:
            return pd.read_csv(csv_file, dtype='str')

        if query is not None:

            return pd.DataFrame.from_dict(query)

    def perform_find(self, query=None, csv_file=None):
        """
        Method to perform serial C-FIND operations of provided queries

        """
        df = self.load_df(query, csv_file)

        results = None
        for n, row in df.iterrows():
            results = perform_find(configs=self.server, query=row.to_dict(), results=results)

        results = pd.DataFrame.from_dict(results)

        return results

    def perform_move(self, query=None, csv_file=None):
        """
        Method to perform serial C-MOVE operations of provided queries

        """
        df = self.load_df(query, csv_file)

        for n, row in df.iterrows():
            perform_move(configs=self.server, query=row.to_dict())
