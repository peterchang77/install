import os, shutil, glob, yaml, time
from datetime import datetime
from .pacs import PACSClient
from jarvis.utils.general import printd, FileDaemon 

class PACSDaemon(FileDaemon):

    def init_custom(self):

        self.name = 'PACS-Requests'

        # --- Create clients
        self.pc = PACSClient()

        # --- Copy configs from client to self
        self.pacsd = self.pc.pacsd
        self.requests = self.pc.requests

    def exec_actions(self, paths):
        """
        Method to trigger download 

        """
        # --- Process files in parse 
        self.process_parse()

        # --- Process files in queue 
        self.process_queue()

    def find_requests(self, name, ext='*'):
        """
        Method to return all files in requests directory

        """
        return glob.glob('{}/*.{}'.format(self.requests[name], ext))

    def process_parse(self):
        """
        Method to parse all pending requests 

        """
        # --- Find all pending *.csv files
        for csv in self.find_requests('parse', ext='csv'):
            self.parse_request(csv)

    def parse_request(self, csv):
        """
        Method to split request into N-parts based on batch-size defined in request.yml file

        """
        # --- Find base request name
        name = os.path.basename(csv)[:-4]

        # --- Find corresponding YML file
        yml = csv[:-4] + '.yml'
        yml = yml if os.path.exists(yml) else self.requests['default-yml']

        # --- Split into parts
        df = self.load_csv(csv)
        bs = self.load_yml(yml)['batch-size']

        for n, i in enumerate(range(0, df.shape[0], bs)):

            dst_csv = '{}/{}.part-{:03d}.csv'.format(self.requests['queue'], name, n)
            dst_yml = '{}/{}.part-{:03d}.yml'.format(self.requests['queue'], name, n)

            part = df.iloc[i:i+bs]
            part.to_csv(dst_csv, index=False)
            shutil.copy(src=yml, dst=dst_yml)

        # --- Remove files
        os.remove(csv)
        if yml != self.requests['default-yml']:
            os.remove(yml)

        # --- Printd
        printd('Parsed request for: {} (total {:03d} parts)'.format(name, n + 1))

    def process_queue(self):
        """
        Method to process queue for pending downloads

        """
        if not self.is_ready_for_next_download():
            return

        # --- Find next request
        req = self.find_next_request()

        if req is None:
            return

        # --- PACSClient C-MOVE request
        self.pc.perform_move(csv_file=req['csv'])

        # --- Move request from queue to await 
        shutil.move(src=req['csv'], dst=req['csv'].replace(self.requests['queue'], self.requests['await']))
        shutil.move(src=req['yml'], dst=req['yml'].replace(self.requests['queue'], self.requests['await']))

        # --- Printd
        printd('Processed queue item: {} '.format(os.path.basename(req['yml'][:-4])))

    def find_next_request(self):

        ymls = self.find_requests(name='queue', ext='yml') 

        # --- Find lowest part count for reach request 
        ymls_ = []
        names = []

        for yml in sorted(ymls):
            name = os.path.basename(yml).split('.')[0]
            if name not in names:
                names.append(name)
                ymls_.append(yml)

        # --- Arrange by time of creation
        ymls_.sort(key=os.path.getmtime)

        # --- Find first YML that exists in current time window
        for yml in ymls_:

            y = self.load_yml(yml)

            lo = y['lower-time'] or 0
            hi = y['upper-time'] or 2400

            if int(lo) < self.get_time() < int(hi):
                return {
                    'yml': yml,
                    'csv': yml[:-4] + '.csv'} 

    def is_ready_for_next_download(self): 
        """
        Method to check if download delay has been fulfilled

        """
        elapsed = time.time() - os.stat(self.ENV['PACS_PATH_DOWNLOAD']).st_mtime

        return elapsed > self.pacsd['delay-until-next-download']

    def get_time(self):

        return int(datetime.now().strftime('%H%M'))
