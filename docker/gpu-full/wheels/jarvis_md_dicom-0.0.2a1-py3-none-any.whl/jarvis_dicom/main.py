import glob, numpy as np
import pydicom

def load_datasets_and_fnames(func):

    def wrapper(fname=None, ext='.dcm', datasets=None, headers_only=False, *args, **kwargs):

        # --- Load if needed 
        if datasets is None or type(fname) is not list:
            datasets, fnames = load_datasets(fname, ext=ext, stop_before_pixels=headers_only)
        else: 
            fnames = fname

        assert len(datasets) == len(fnames), 'ERROR len of provided datasets and fnames must match'

        return func(fnames=fnames, datasets=datasets, headers_only=headers_only, *args, **kwargs)

    return wrapper

@load_datasets_and_fnames
def load(fnames, datasets, pixel_array=None, headers_only=False, all_headers_raw=False, dtype=None, **kwargs):
    """
    Method to load DICOM object(s) from single series

    """
    # --- Sort datasets
    ds, fs = filter_and_sort_datasets(datasets, fnames, stop_before_pixels=headers_only)

    # --- Extract arr and header
    data = load_pixel_array(datasets=ds, fnames=fs, pixel_array=pixel_array, headers_only=headers_only, dtype=dtype) if len(ds) > 0 else None
    meta = load_header(datasets=datasets, ds=ds, all_headers_raw=all_headers_raw)

    meta['fnames-orig'] = fnames 
    meta['fnames-sort'] = fs

    return data, meta 

@load_datasets_and_fnames
def load_multidimensional(fnames, datasets, **kwargs):
    """
    Method to load DICOM object(s) from single series with separate handlers for 2D and 3D data

      2D data ==> load as individual images (even if part of a single series UID)
      3D data ==> load as individual volumes

    NOTE: 2D and 3D data is determined by definitions in is_cross_sectional(...) method

    """
    series = {}

    if len(datasets) == 0:
        return series

    # --- Split 2D vs 3D
    _2d = {'datasets': [], 'fname': []} 
    _3d = {'datasets': [], 'fname': []} 

    for f, d in zip(fnames, datasets):
        if is_cross_sectional(dataset=d):
            _3d['datasets'].append(d)
            _3d['fname'].append(f)
        else:
            _2d['datasets'].append(d)
            _2d['fname'].append(f)

    # --- Lambda functions
    shape = lambda data : {
        'z': getattr(data, 'shape', [0, 0, 0])[0],
        'y': getattr(data, 'shape', [0, 0, 0])[1],
        'x': getattr(data, 'shape', [0, 0, 0])[2]}

    uid = datasets[0].get('SeriesInstanceUID', '')

    # --- Load 3D 
    if len(_3d['datasets']) > 0:
        data, meta = load(**_3d, **kwargs)
        keys = {**{'uid': uid}, **shape(data)}
        series['3d_z-{z:04d}_y-{y:04d}_x-{x:04d}_uid-{uid}'.format(**keys)] = {'data': data, 'meta': meta}

    # --- Load 2D individually
    n = 0
    for d, s in zip(_2d['datasets'], _2d['fname']):
        data, meta = load(fname=f, datasets=d, **kwargs)
        keys = {**{'uid': uid, 'n': n}, **shape(data)}
        series['2d_z-{z:04d}_y-{y:04d}_x-{x:04d}_uid-{uid}-{n:04d}'.format(**keys)] = {'data': data, 'meta': meta}
        n += 1

    return series

@load_datasets_and_fnames
def load_multiseries(fnames, datasets, **kwargs):
    """
    Method to load DICOM object(s) from multiple series

    """
    # --- Organize into series
    uids = [ds.get('SeriesInstanceUID', '') for ds in datasets]
    d = {u: {'datasets': [], 'fname': []} for u in set(uids)}

    for uid, dataset, fname in zip(uids, datasets, fnames):
        d[uid]['datasets'].append(dataset)
        d[uid]['fname'].append(fname)

    # --- Load all series
    series = {}

    for uid, df in d.items():

        series.update(load_multidimensional(**df, **kwargs))

    return series

def load_pixel_array(datasets, fnames, pixel_array=None, headers_only=False, dtype=None):

    if pixel_array is not None:
        return pixel_array

    rows = datasets[0].Rows
    cols = datasets[0].Columns
    samp = datasets[0].SamplesPerPixel      # --- Account for RGB, etc
    temp = extract_num_channels(datasets)   # --- Account for 4D, etc

    shape = (rows, cols, len(datasets)) if samp == 1 else (rows, cols, samp, len(datasets))

    if hasattr(datasets[0], 'PixelData') and not headers_only:

        try:
            voxels = np.zeros(shape, dtype='float32')

            for k in range(len(datasets)):

                slope = float(getattr(datasets[k], 'RescaleSlope', 1))
                intercept = float(getattr(datasets[k], 'RescaleIntercept', 0))
                voxels[..., k] = read_pixel_array(datasets[k], fnames[k]) * slope + intercept

            # --- Reshape (accounting for 4D acquisitions) 
            voxels = voxels.reshape(rows, cols, -1, int(temp * samp))
            voxels = np.moveaxis(voxels, 2, 0)

            if dtype is None:
                dtype = 'int16' if slope.is_integer() else 'float16'

            return voxels.astype(dtype)

        except:
            pass

    return np.zeros((int(len(datasets) / temp), rows, cols, int(temp * samp)), dtype='int16')

def read_pixel_array(dataset, fname):
    """
    Method to attempt pixel array extraction

    """
    for func in pixel_load_funcs:

        try:

            pixel_array = func(dataset, fname)
            return pixel_array.astype('float32')

        except: pass

    return np.array(0, dtype='float32')

def find_pixel_loaders():
    """
    Method all available DICOM pixel-data load libraries

    """
    pixel_load_funcs = []

    # --- pydicom (default)
    pixel_load_funcs.append(lambda dataset, fname : dataset.pixel_array)

    # --- mudicom (for compressed DICOM files)
    try:
        import mudicom
        pixel_load_funcs.append(lambda dataset, fname : mudicom.load(fname).image.numpy)
    except: pass

    return pixel_load_funcs 

def load_header(path=None, datasets=None, ds=None, all_headers_raw=False):

    if datasets is None:
        datasets, fnames = load_datasets(path, stop_before_pixels=True)

    if ds is None:
        ds, fs = filter_and_sort_datasets(datasets, fnames, stop_before_pixels=True)

    meta = {}

    if len(ds) == 0:
        meta['header'] = extract_dicom_headers(datasets[0], all_headers_raw)
        meta['affine'] = None

    else:
        spacing = extract_spacing(ds)
        meta['header'] = extract_dicom_headers(ds[0], all_headers_raw)
        meta['affine'] = calculate_affine(ds, spacing)

    return meta 

def load_datasets(path, stop_before_pixels=False, ext='.dcm', **kwargs):
    """
    Method to load all DICOM files in path

    """
    # --- Find fnames
    fnames = find_fnames(path, ext)

    # --- Load datasets
    datasets = [pydicom.read_file(f, force=True, stop_before_pixels=stop_before_pixels) for f in fnames]

    return datasets, fnames

def find_fnames(path, ext):

    if type(path) is list:
        fnames = path

    else:
        if path[-4:] == ext:
            fnames = [path]

        else:
            if path[-1] != '/': path += '/'
            fnames = glob.glob('%s*%s' % (path, ext)) 
            if len(fnames) == 0:
                fnames = glob.glob('%s*' % path) 
            assert len(fnames) > 0, 'Error no DICOM files found in path'

    return fnames 

def filter_and_sort_datasets(datasets, fnames, stop_before_pixels=False, **kwargs):

    # --- Filter datasets (ensure presence of certain header fields)
    datasets, fnames = filter_datasets(datasets, fnames, stop_before_pixels=stop_before_pixels)

    if len(datasets) == 0:
        return datasets, fnames

    # --- Sort by instance number (for 4D) then by position
    datasets, fnames = sort_slices_by_instance(datasets, fnames)
    datasets, fnames = sort_slices_by_position(datasets, fnames)

    return datasets, fnames

def filter_datasets(datasets, fnames, stop_before_pixels):
    """
    Method to filter datasets by presence of fields

    """
    if len(datasets) == 1:
        setattr(datasets[0], 'ImageOrientationPatient', [1, 0, 0, 0, 1, 0])
        setattr(datasets[0], 'ImagePositionPatient', [0, 0, 0])

    # --- Remove redundant SOPInstanceUIDs
    datasets, fnames = filter_datasets_unique_uid(datasets=datasets, fnames=fnames)

    # --- Filter by required fields 
    REQ_FIELDS = ['ImageOrientationPatient', 'ImagePositionPatient', 'Rows', 'Columns', 'SamplesPerPixel']
    if not stop_before_pixels:
        REQ_FIELDS.append('PixelData')

    indices = [all([hasattr(d, r) for r in REQ_FIELDS]) for d in datasets]
    datasets = [d for i, d in zip(indices, datasets) if i] 
    fnames = [f for i, f in zip(indices, fnames) if i] 

    # --- Filter by common values
    for field, dtype in {
        'ImageOrientationPatient': lambda x : np.around(np.array(x), 5).tobytes(),
        'Rows': int,
        'Columns': int,
        'SamplesPerPixel': int}.items():

        if len(datasets) == 0:
            break

        f = [dtype(getattr(d, field)) for d in datasets]
        datasets, fnames = filter_by_mode(f=f, datasets=datasets, fnames=fnames)

    return datasets, fnames 

def filter_datasets_unique_uid(datasets=None, fnames=None, path=None, ext='.dcm'):

    if datasets is None:
        datasets, fnames = load_datasets(fnames or path, ext=ext, stop_before_pixels=True)

    d = {fs: ds for fs, ds in zip(fnames, datasets)}
    d = {fs: d[fs] for fs in sorted(fnames)}

    # --- Retain unique SOPInstanceUIDs
    u = {getattr(ds, 'SOPInstanceUID', None): fs for fs, ds in d.items()}

    fnames = list(u.values())
    datasets = [d[fs] for fs in fnames]

    return datasets, fnames

def filter_by_mode(f, datasets, fnames):
    """
    Method to filter datasets by the most common value in iterable f

    """
    mode = max(sorted(set(f)), key=f.count)
    matches = [m == mode for m in f]
    datasets = [d for m, d in zip(matches, datasets) if m]
    fnames = [n for m, n in zip(matches, fnames) if m]

    return datasets, fnames

def calculate_affine(datasets, spacing):
    """
    Method to calculate ijk to xyz (real patient coordinates) affine transform

    """
    cos = extract_cosines(datasets)

    affine = np.identity(4, dtype=np.float32)

    affine[:3, 0] = (cos['row'] * spacing['col'])
    affine[:3, 1] = (cos['col'] * spacing['row'])
    affine[:3, 2] = (cos['slices'] * spacing['slices'])

    affine[:3, 3] = datasets[0].ImagePositionPatient

    # =================================================
    # Convert to ZYX instead of XYZ (default)
    # =================================================
    # 
    # ORIGINAL
    #
    #     [[x1, y1, z1, x4],  *  [[i],
    #      [x2, y2, z2, y4],      [j],
    #      [x3, y3, z3, z4],      [k],
    #      [0 , 0 , 0 , 1]]       [1]]
    # 
    # X = x1 * i + y1 * j + z1 * k + x4
    # Y = x2 * i + y2 * j + z2 * k + y4
    # Z = x3 * i + y3 * j + z3 * k + z4
    # 
    # CONVERTED
    #
    #     [[z3, y3, x3, z4],  *  [[k],
    #      [z2, y2, x2, y4],      [j],
    #      [z1, y1, x1, x4],      [i],
    #      [0,  0,  0,  1]]       [1]]
    # 
    # Z = z3 * k + y3 * j + x3 * i + z4
    # Y = z2 * k + y2 * j + x2 * i + y4
    # X = z1 * k + y1 * j + x1 * i + x4
    # 
    # =================================================

    affine[:3, :3] = affine[2::-1, 2::-1]
    affine[:3, 3] = affine[2::-1, 3]

    return affine 

def extract_spacing(datasets):

    spacing = {}

    # --- Extract xy-spacing
    ps = getattr(datasets[0], 'PixelSpacing', [1, 1]) or [1, 1]
    spacing['row'] = float(ps[0])
    spacing['col'] = float(ps[1])

    # --- Extract z-spacing
    if len(datasets) > 1:
        spacing['slices'] = extract_slice_thickness(datasets) 

    else:
        spacing['slices'] = 1.

    return spacing

def extract_cosines(datasets):
    """
    Method extract direction cosines from DICOM image orientation vector

    Note that if direction cosines in ImageOrientationPatient header are not unit length,
    the values are normalized.

    Note that while row and column cosines are extracted from ImageOrientationPatient,
    the slice cosine is calculated from adjacent ImagePositionPatient headers because
    the z-axis is NOT guaranteed to be perpendicular to the XY-axis.

      cos['row'] = from ImageOrientationPatient
      cos['col'] = from ImageOrientationPatient
      cos['slices'] = from ImagePositionPatient

    IMPORTANT: it is assumed that datasets is sorted already by IPP

    """
    cos = {}

    dist = lambda x : np.sqrt(np.sum(x ** 2)) if np.sum(x) > 0 else 1
    norm = lambda x : x / dist(x)

    cos['row'] = norm(np.array(datasets[0].ImageOrientationPatient[:3]))
    cos['col'] = norm(np.array(datasets[0].ImageOrientationPatient[3:]))

    if len(datasets) == 1:
        cos['slices'] = np.array([0, 0, 1])

    else:
        ipp = np.array([d.ImagePositionPatient for d in datasets])
        xyz = np.mean(ipp[1:] - ipp[:-1], axis=0)
        cos['slices'] = norm(xyz) 

    return cos 

def extract_slice_thickness(datasets):
    """
    Method to measure distance between adjacent slices based on ImagePositionPatient

    """
    cha = extract_num_channels(datasets)
    ipp = np.array([d.ImagePositionPatient for d in datasets])[::cha]

    if ipp.shape[0] <= 1:

        return 1.

    xyz = np.mean(ipp[1:] - ipp[:-1], axis=0)

    return np.sqrt(np.sum(xyz ** 2)) 

def extract_slice_positions(datasets):
    """
    Method to extract slice positions by applying dot product of sli_cosine to 

    """
    cos = extract_cosines(datasets)
    slice_positions = [np.dot(cos['slices'], d.ImagePositionPatient) for d in datasets]

    return slice_positions 

def extract_num_channels(datasets):
    """
    Method to extract total number of channels by looking for repeat slice positions 

    """
    if len(datasets) == 1:
        return 1

    slice_positions = extract_slice_positions(datasets)
    n = len(slice_positions) 
    u = len(set(slice_positions))
    channels = int(n / u) if n % u == 0 else 1

    return channels

def sort_slices_by_instance(datasets, fnames):
    """
    Method to sort slices by instance number (if present)

    """
    if not hasattr(datasets[0], 'InstanceNumber'):
        return datasets, fnames

    slice_instances = [getattr(d, 'InstanceNumber', n) for n, d in enumerate(datasets)]

    datasets= [d for s, d in sorted(zip(slice_instances, datasets), key=lambda x:x[0])]
    fnames = [f for s, f in sorted(zip(slice_instances, fnames), key=lambda x:x[0])]

    return datasets, fnames

def sort_slices_by_position(datasets, fnames):
    """
    Method to sort slices by ImagePositionPatient 

    Note that this method sorts by IPP along the index (dimension) that spans the greatest distance 

    Importantly there no assumptions of any pre-sorting (e.g. via InstanceNumber), etc

    """
    ipp = np.array([d.ImagePositionPatient for d in datasets])
    ext = find_extreme_ipp(ipp)
    ind = np.argmax(np.abs(np.diff(ext, axis=0)))

    slice_positions = ipp[:, ind]

    datasets= [d for s, d in sorted(zip(slice_positions, datasets), key=lambda x:x[0])]
    fnames = [f for s, f in sorted(zip(slice_positions, fnames), key=lambda x:x[0])]

    return datasets, fnames

def find_extreme_ipp(ipp):
    """
    Method to find extreme values of ImagePositionPatient (assumed to be unsorted)

    """
    assert ipp.ndim == 2
    assert ipp.shape[1] == 3

    a = ipp.reshape(-1, 1, 3)
    b = ipp.reshape(1, -1, 3)

    dist = np.sum((a - b) ** 2, axis=2)
    i, j = np.unravel_index(np.argmax(dist), dist.shape)

    return np.stack((ipp[i], ipp[j]))

def extract_dicom_headers(dataset, all_headers_raw=False):

    DEFAULTS = {
        'PatientID': '',
        'StudyInstanceUID': '',
        'SeriesInstanceUID': '',
        'AccessionNumber': '',
        'Modality': '', 
        'StudyDescription': '',
        'SeriesDescription': '',
        'StudyDate': 19000101,
        'AcquisitionTime': 0.0,
        'AcquisitionNumber': None}

    d = {convert_to_snake_case(k): format_header(dataset, k, v) for k, v in DEFAULTS.items()}

    # --- MR attributes
    if hasattr(dataset, 'RepetitionTime'):

        DEFAULTS = {
            'RepetitionTime': None,
            'EchoTime': None,
            'EchoTrainLength': None,
            'EchoNumbers': None,
            'InversionTime': None,
            'MagneticFieldStrength': None,
            'PercentSampling': None,
            'FlipAngle': None}

        d['protocol'] = {convert_to_snake_case(k): format_header(dataset, k, v) for k, v in DEFAULTS.items()}

    # --- XR/CT attributes
    if hasattr(dataset, 'KVP'):

        DEFAULTS = {
            'KVP': None, 
            'XRayTubeCurrent': None,
            'ExposureTime': None,
            'ConvolutionKernel': ''}

        d['protocol'] = {convert_to_snake_case(k): format_header(dataset, k, v) for k, v in DEFAULTS.items()}

    # --- Include all raw
    if all_headers_raw:
        d['_raw'] = {e.description().replace(' ', '').strip(' "\''): 
            format_header(value=e.repval) for e in dataset.iterall() if type(e.value) is not bytes}

    return d

def format_header(dataset=None, key=None, default=None, value=None):

    value = value or getattr(dataset, key, default)

    if value is None or len(str(value)) == 0:
        return value

    value = str(value).strip(' "\'')

    if type(default) is str:
        return value

    for func in [int, float]:
        try:
            return func(value)
        except: pass
        finally: pass

    return value

def convert_to_snake_case(k):
    """
    Method to convert CamelCase to snake_case

    """
    KEY = {
        'PatientID': 'pid',
        'StudyInstanceUID': 'study_uid',
        'SeriesInstanceUID': 'series_uid',
        'AccessionNumber': 'accession',
        'Modality': 'modality', 
        'StudyDescription': 'study_description',
        'SeriesDescription': 'series_description', 
        'StudyDate': 'date',
        'AcquisitionTime': 'time',
        'AcquisitionNumber': 'acquisition_number',
        'RepetitionTime': 'TR',
        'EchoTime': 'TE',
        'EchoTrainLength': 'echo_train_length',
        'EchoNumbers': 'echo_numbers',
        'InversionTime': 'inversion_time',
        'MagneticFieldStrength': 'magnetic_field_strength',
        'PercentSampling': 'percent_sampling',
        'FlipAngle': 'flip_angle',
        'KVP': 'kVp', 
        'XRayTubeCurrent': 'mA',
        'ExposureTime': 'mAs',
        'ConvolutionKernel': 'convolution_kernel'}

    return KEY.get(k, k)

def list_headers_phi():
    """
    Method to list currently extracted headers with potential PHI information

    """
    return {
        'PatientID': 'pid',
        'StudyInstanceUID': 'study_uid',
        'SeriesInstanceUID': 'series_uid',
        'AccessionNumber': 'accession'}

def is_cross_sectional(dataset=None, fname=None):
    """
    Method to infer cross-sectional status

    NOTE: will need to update for US

    """
    dataset = dataset or pydicom.read_file(fname, stop_before_pixels=True)

    return hasattr(dataset, 'ImagePositionPatient') or (getattr(dataset, 'SamplesPerPixel', 1) > 1)

# =======================================================================
pixel_load_funcs = find_pixel_loaders()
# =======================================================================
