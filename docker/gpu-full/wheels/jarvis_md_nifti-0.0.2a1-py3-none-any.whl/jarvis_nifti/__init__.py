from .main import load_nifti 
